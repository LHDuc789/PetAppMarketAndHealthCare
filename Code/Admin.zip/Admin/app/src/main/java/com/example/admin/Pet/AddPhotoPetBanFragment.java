package com.example.admin.Pet;

import static android.app.Activity.RESULT_OK;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.admin.Main.MainActivity;
import com.example.admin.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;


public class AddPhotoPetBanFragment extends Fragment {

    private View AddPhotoPetBanView;
    private MainActivity mainActivity;

    private Button btnAdd;
    private Button btnCancel;



    private Uri uriImageIcon;

    private Uri uriImage1;
    private Uri uriImage2;
    private Uri uriImage3;

    private ImageView ivImg;
    private ImageView ivImg_add_1;
    private ImageView ivImg_add_2;
    private ImageView ivImg_add_3;

    private ProgressDialog progressDialog;


    PetBan newPetBan;


    public AddPhotoPetBanFragment() {
        // Required empty public constructor
    }


    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static AddPhotoPetBanFragment getInstance(PetBan petban){
        AddPhotoPetBanFragment addPhotoPetBanFragment = new AddPhotoPetBanFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_photopetban", petban);
        addPhotoPetBanFragment.setArguments(bundle);
        return addPhotoPetBanFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        AddPhotoPetBanView =  inflater.inflate(R.layout.fragment_add_photo_pet_ban, container, false);
        mainActivity = (MainActivity) getActivity();

        //Ánh xạ view
        initUI();
        return AddPhotoPetBanView;
    }


    private void initUI() {
        progressDialog = new ProgressDialog(mainActivity);

        btnAdd = AddPhotoPetBanView.findViewById(R.id.btnAdd);
        btnCancel = AddPhotoPetBanView.findViewById(R.id.btnCancel);

        ivImg = AddPhotoPetBanView.findViewById(R.id.ivImg);

        ivImg_add_1 = AddPhotoPetBanView.findViewById(R.id.ivImg_add_1);
        ivImg_add_2 = AddPhotoPetBanView.findViewById(R.id.ivImg_add_2);
        ivImg_add_3 = AddPhotoPetBanView.findViewById(R.id.ivImg_add_3);

        newPetBan = (PetBan) getArguments().get("object_photopetban");


        //Lay anh tu dien thoai up len ImageView co id la ivImg.
        ivImg.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 2);
        });

        //Lay anh tu dien thoai up len ImageView co id la ivImg_add_1.
        ivImg_add_1.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 3);
        });

        //Lay anh tu dien thoai up len ImageView co id la ivImg_add_2.
        ivImg_add_2.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 4);
        });

        //Lay anh tu dien thoai up len ImageView co id la ivImg_add_3.
        ivImg_add_3.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 5);
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(uriImageIcon == null){
                    Toast.makeText(mainActivity,"Vui Lòng Không Để Trống Ảnh Đại Diện Của Thú Cưng.",Toast.LENGTH_LONG).show();
                }

                else if(uriImage1 == null){
                    Toast.makeText(mainActivity,"Vui Lòng Không Để Trống Ảnh Phụ Thứ Nhất Của Thú Cưng.",Toast.LENGTH_LONG).show();
                }

                else if(uriImage2 == null){
                    Toast.makeText(mainActivity,"Vui Lòng Không Để Trống Ảnh Phụ Thứ Hai Của Thú Cưng.",Toast.LENGTH_LONG).show();
                }

                else if(uriImage3 == null){
                    Toast.makeText(mainActivity,"Vui Lòng Không Để Trống Ảnh Phụ Thứ Ba Của Thú Cưng.",Toast.LENGTH_LONG).show();
                }

                else {
                    //Goi Database voi parent key la PetBan.
                    DatabaseReference root = FirebaseDatabase.getInstance().getReference("PetBan");
                    root.child(String.valueOf(newPetBan.getIdPet())).setValue(newPetBan);

                    progressDialog.setMessage("Đang Thêm Một Thú Cưng Mới");
                    progressDialog.show();

                    //Doi 3 giay.
                    Handler handler = new Handler();
                    handler.postDelayed(() -> {
                        progressDialog.dismiss();
//                        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
//                        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
//                        fragmentTransaction.replace(R.id.root_view, new PetFragment());
//                        //Back lai content_frame ma van luu trang thai truoc.
//                        fragmentTransaction.addToBackStack(null);
//                        fragmentTransaction.commit();
                        Toast.makeText(mainActivity,"Thêm Thành Công Đối Tượng " + newPetBan.getNameOfType(),Toast.LENGTH_LONG).show();
                        FragmentManager fmManager = getActivity().getSupportFragmentManager();
                        fmManager.popBackStack();
                        fmManager.popBackStack();
                    },2000);
                }
            }
        });

        //Khi huy thi tat ca cac anh da upload len server se duoc xoa het.
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();

                if(!newPetBan.getUrlImageIcon().isEmpty()){
                    StorageReference storageReference = firebaseStorage.getReferenceFromUrl(newPetBan.getUrlImageIcon());
                    storageReference.delete();
                    newPetBan.setUrlImageIcon("");

                }
                if(!newPetBan.getUrlImage1().isEmpty()){
                    StorageReference storageReference1 = firebaseStorage.getReferenceFromUrl(newPetBan.getUrlImage1());
                    storageReference1.delete();
                    newPetBan.setUrlImage1("");
                }

                if(!newPetBan.getUrlImage2().isEmpty()){
                    StorageReference storageReference2 = firebaseStorage.getReferenceFromUrl(newPetBan.getUrlImage2());
                    storageReference2.delete();
                    newPetBan.setUrlImage2("");
                }

                if(!newPetBan.getUrlImage3().isEmpty()){
                    StorageReference storageReference3 = firebaseStorage.getReferenceFromUrl(newPetBan.getUrlImage3());
                    storageReference3.delete();
                    newPetBan.setUrlImage3("");
                }

                if(newPetBan.getUrlImageIcon().isEmpty() & newPetBan.getUrlImage1().isEmpty() && newPetBan.getUrlImage2().isEmpty() && newPetBan.getUrlImage3().isEmpty()){
                    FragmentManager fmManager = getActivity().getSupportFragmentManager();
                    fmManager.popBackStack();
                    fmManager.popBackStack();
                }

            }
        });
    }


    private void uploadToFireBase0(Uri uriImage0, PetBan petban) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetBan").child(petban.getNameOfType());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage0));

        if(!petban.getUrlImageIcon().equals("")){
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(petban.getUrlImageIcon());
            storageReference.delete();
        }

        progressDialog.setMessage("Đang Thêm Ảnh Đại Diện Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage0).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                petban.setUrlImageIcon(String.valueOf(uri1));
                progressDialog.dismiss();
                Toast.makeText(mainActivity,"Thêm Thành Công Ảnh Đại Diện Cho Thú Cưng.",Toast.LENGTH_LONG).show();
            });
        });

    }

    private void uploadToFireBase1(Uri uriImage1, PetBan petban) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetBan").child(petban.getNameOfType());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage1));

        if(!petban.getUrlImage1().equals("")){
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(petban.getUrlImage1());
            storageReference.delete();
        }

        progressDialog.setMessage("Đang Thêm Ảnh Phụ Thứ Nhất Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage1).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                petban.setUrlImage1(String.valueOf(uri1));
                progressDialog.dismiss();
                Toast.makeText(mainActivity,"Thêm Thành Công Ảnh Phụ Thứ Nhất Cho Thú Cưng.",Toast.LENGTH_LONG).show();
            });
        });

    }

    private void uploadToFireBase2(Uri uriImage2, PetBan petban) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetBan").child(petban.getNameOfType());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage2));

        if(!petban.getUrlImage2().equals("")){
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(petban.getUrlImage2());
            storageReference.delete();
        }

        progressDialog.setMessage("Đang Thêm Ảnh Phụ Thứ Hai Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage2).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                petban.setUrlImage2(String.valueOf(uri1));
                progressDialog.dismiss();

                Toast.makeText(mainActivity,"Thêm Thành Công Ảnh Phụ Thứ Hai Cho Thú Cưng.",Toast.LENGTH_LONG).show();

            });
        });

    }

    private void uploadToFireBase3(Uri uriImage3, PetBan petban) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetBan").child(petban.getNameOfType());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage3));

        if(!petban.getUrlImage3().equals("")){
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(petban.getUrlImage3());
            storageReference.delete();
        }

        progressDialog.setMessage("Đang Thêm Ảnh Phụ Thứ Ba Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage3).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                petban.setUrlImage3(String.valueOf(uri1));
                progressDialog.dismiss();
                Toast.makeText(mainActivity,"Thêm Thành Công Ảnh Phụ Thứ Ba Cho Thú Cưng.",Toast.LENGTH_LONG).show();

            });
        });

    }

    //Ham dat ten cho file anh khi upload len Storage.
    private String getFileExtension(Uri mUri) {
        ContentResolver cr = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));
    }


    //Ham tra ve ket qua va phan hoi de dua anh len ImageView.
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==2 && resultCode == RESULT_OK && data != null){
            uriImageIcon = data.getData();
            ivImg.setImageURI(uriImageIcon);
            uploadToFireBase0(uriImageIcon, newPetBan);
        }

        if(requestCode==3 && resultCode == RESULT_OK && data != null){
            uriImage1 = data.getData();
            ivImg_add_1.setImageURI(uriImage1);
            uploadToFireBase1(uriImage1, newPetBan);

        }

        if(requestCode==4 && resultCode == RESULT_OK && data != null){
            uriImage2 = data.getData();
            ivImg_add_2.setImageURI(uriImage2);
            uploadToFireBase2(uriImage2, newPetBan);

        }

        if(requestCode==5 && resultCode == RESULT_OK && data != null) {
            uriImage3 = data.getData();
            ivImg_add_3.setImageURI(uriImage3);
            uploadToFireBase3(uriImage3, newPetBan);
        }

    }

    //An nut add o option menu di khi o trang fragment nay.
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item=menu.findItem(R.id.btnAddCustomer);
        if(item!=null)
            item.setVisible(false);
    }
}