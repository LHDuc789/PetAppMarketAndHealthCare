package com.example.admin.Interface;

import com.example.admin.ProfitPackage.Profit;
import com.example.admin.User.Customer;

public interface ClickItemProfit {
    void onClickItemProfit(Profit profit);
}
