package com.example.admin.Interface;

import com.example.admin.User.Customer;

public interface ClickItemCustomer {
    void onClickItemCustomer(Customer customer);
    void onClickDeleteCustomer(Customer customer);
}
