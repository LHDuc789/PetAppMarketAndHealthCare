package com.example.admin.Pet;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.admin.Interface.ClickItemPetBan;
import com.example.admin.R;

import java.util.List;

public class PetBanAdapter extends RecyclerView.Adapter<PetBanAdapter.ViewHolder>{
    private List<PetBan> mPetBan;
    private final Context mContext;
    private final ClickItemPetBan clickItemPetBanListener;


    public PetBanAdapter(Context mContext,List _petbans, ClickItemPetBan listener){
        this.mContext = mContext;
        this.mPetBan = _petbans;
        this.clickItemPetBanListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View petbanView = inflater.inflate(R.layout.petban_item,parent,false);
        return new ViewHolder(petbanView);
    }

    @SuppressLint("DefaultLocale")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Lay ra vi tri cua thang object Games bat ki khi duoc click
        final PetBan petban = (PetBan) mPetBan.get(position);
        if (petban == null){
            return;
        }

        holder.tvName.setText(petban.getNameOfType());
        holder.tvCost.setText("Giá Tiền: " + petban.getCost() + " VND");

        //Su dung thu vien Glide de load anh lay tu firebase ve.
        Glide.with(mContext).load(petban.getUrlImageIcon()).into(holder.ivImg);
//        holder.ivImg.setImageResource(games.getImg());

        holder.PetBanListItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickItemPetBanListener.onClickItemPetBan(petban);
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickItemPetBanListener.onClickDeletePetBan(petban);
            }
        });

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickItemPetBanListener.onClickEditPetBan(petban);
            }
        });



    }

    @Override
    public int getItemCount() {
        return mPetBan.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvName;
        public TextView tvCost;
        public ImageView ivImg;
        public LinearLayout PetBanListItem;
        public ImageButton btnEdit,btnDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            ivImg = itemView.findViewById(R.id.ivImg);
            tvName = itemView.findViewById(R.id.tvName);
            tvCost = itemView.findViewById(R.id.tvCost);
            PetBanListItem = itemView.findViewById(R.id.PetBanListItem);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);

        }
    }
}
