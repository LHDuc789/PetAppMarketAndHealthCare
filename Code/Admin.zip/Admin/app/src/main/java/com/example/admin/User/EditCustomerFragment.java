package com.example.admin.User;

import static android.app.Activity.RESULT_OK;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.bumptech.glide.Glide;
import com.example.admin.Main.MainActivity;
import com.example.admin.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Date;


@SuppressWarnings("ALL")
public class EditCustomerFragment extends Fragment {


    private ImageView ivImg;
    private EditText etName;
    private EditText etAddress;
    private TextView tvEmail;
    private EditText etPhone;
    private Button btnComplete;
    private Button btnCancel;

    private ProgressDialog progressDialog;


    private Uri uriImageIcon;

    private  String newName, newAddress, newPhone, email;

    Customer customer;


    private View EditCustomerView;
    private MainActivity mainActivity;

//    private final ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
//        @Override
//        public void onActivityResult(ActivityResult result) {
//            if(result.getResultCode() == RESULT_OK){
//                Intent intent = result.getData();
//                if(intent == null){
//                    return;
//                }
//                uriImageUserIcon = intent.getData();
//                ivImg.setImageURI(uriImageUserIcon);
//            }
//        }
//    });

//    public static final int MY_REQUEST_CODE = 10000;



    public EditCustomerFragment() {
        // Required empty public constructor
    }

    //Lay du lieu object tu Activity de dua sang EditCustomerFragment.
    public static EditCustomerFragment getInstance(Customer customer){
        EditCustomerFragment editCustomerFragment = new EditCustomerFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_edit_customer",customer);
        editCustomerFragment.setArguments(bundle);
        return editCustomerFragment;
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        EditCustomerView = inflater.inflate(R.layout.fragment_edit_customer, container, false);
        mainActivity = (MainActivity) getActivity();

        initUi();
        initListener();
        return EditCustomerView;
    }

    

    private void initUi() {
        progressDialog = new ProgressDialog(mainActivity);
        ivImg = EditCustomerView.findViewById(R.id.ivImg);
        etName = EditCustomerView.findViewById(R.id.etName);
        etAddress = EditCustomerView.findViewById(R.id.etAddress);
        tvEmail = EditCustomerView.findViewById(R.id.tvEmail);
        etPhone = EditCustomerView.findViewById(R.id.etPhone);
        btnComplete = EditCustomerView.findViewById(R.id.btnComplete);
        btnCancel = EditCustomerView.findViewById(R.id.btnCancel);


        //Lay du lieu tu object games ma truyen tu MainActivity sang gan len cac thuoc tinh Fragment.
        customer = (Customer) getArguments().get("object_edit_customer");
        etName.setText(customer.getName());
        etAddress.setText(customer.getAddress());
        tvEmail.setText(customer.getEmail());
        etPhone.setText(customer.getPhone());
        Glide.with(mainActivity).load(customer.getUrlImageIcon()).error(R.drawable.ic_defaultavatar).into(ivImg);
    }

    private void initListener() {

        ivImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                onClickPermission();
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, 2022);
            }
        });

        btnComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                newName = etName.getText().toString().trim();
                newAddress = etAddress.getText().toString().trim();
                newPhone = etPhone.getText().toString().trim();
                email = tvEmail.getText().toString().trim();
                if(TextUtils.isEmpty(newName)){
                    Toast.makeText(mainActivity, "Vui Lòng Nhập Họ Tên Của Bạn.",
                            Toast.LENGTH_SHORT).show();
                }

                else if(TextUtils.isEmpty(newAddress)){
                    Toast.makeText(mainActivity, "Vui Lòng Nhập Địa Chỉ.",
                            Toast.LENGTH_SHORT).show();
                }
                else if(TextUtils.isEmpty(newPhone)){
                    Toast.makeText(mainActivity, "Vui Lòng Nhập Số Điện Thoại.",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    progressDialog.setMessage("Đang Cập Nhật Thông Tin");
                    progressDialog.show();

                    updateProfile();

                    //Doi 3 giay.
                    Handler handler = new Handler();
                    handler.postDelayed(() -> {
                        progressDialog.dismiss();

//                        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
//                        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
//                        fragmentTransaction.replace(R.id.root_view, new PetFragment());
//                        //Back lai content_frame ma van luu trang thai truoc.
//                        fragmentTransaction.addToBackStack(null);
//                        fragmentTransaction.commit();
                        FragmentManager fmManager = getActivity().getSupportFragmentManager();
                        fmManager.popBackStack();
                        fmManager.popBackStack();
                    },3000);
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fmManager = getActivity().getSupportFragmentManager();
                fmManager.popBackStack();
            }
        });
    }

    //Ham tra ve ket qua va phan hoi de dua anh len ImageView.
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2022 && resultCode == RESULT_OK && data != null) {
            uriImageIcon = data.getData();
            ivImg.setImageURI(uriImageIcon);
            uploadToFireBase(uriImageIcon, customer);
        }
    }
//    private void onClickPermission() {
//
//        if(mainActivity == null){
//            return;
//        }
//
//        //Yeu Cau Request Permission tu Android 6 tro len. Duoi thi khong can
//        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.M){
//            openGallery();
//            return;
//        }
//
//        if(getActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
//            openGallery();
//        }
//
//        else {
//            String [] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
//            getActivity().requestPermissions(permissions, MY_REQUEST_CODE);
//        }
//    }


//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == MY_REQUEST_CODE){
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
//                openGallery();
//            }
//            else{
//                Toast.makeText(mainActivity,"Vui lòng cấp quyền truy cập ảnh cho ứng dụng",Toast.LENGTH_LONG).show();
//            }
//        }
//    }


//    private void openGallery() {
//        Intent intent = new Intent();
//        intent.setType("image/*");
//        intent.setAction(Intent.ACTION_GET_CONTENT);
//        activityResultLauncher.launch(Intent.createChooser(intent, "Chọn Ảnh Đại Diện"));
//    }


    private void updateProfile(){
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();


        customer.setName(newName);
        customer.setAddress(newAddress);
        customer.setPhone(newPhone);
        customer.setEmail(email);

        DatabaseReference root = FirebaseDatabase.getInstance().getReference("User");
        root.child(user.getUid()).setValue(customer);
        Handler handler = new Handler();
        handler.postDelayed(() -> {
            Toast.makeText(mainActivity,"Cập Nhật Thông Tin Thành Công",Toast.LENGTH_LONG).show();
        },2000);
    }


    private void uploadToFireBase(Uri uriImage, Customer customer) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("User").child(customer.getEmail());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage));

        if(customer.getUrlImageIcon().equals("https://firebasestorage.googleapis.com/v0/b/petdatabase-c0f2c.appspot.com/o/default%2Fic_defaultavatar.png?alt=media&token=ca253e3e-b6ca-45d8-8d96-a50d8173811b") == false){
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(customer.getUrlImageIcon());
            storageReference.delete();
        }


        progressDialog.setMessage("Đang Cập Nhật Ảnh Đại Diện");
        progressDialog.show();
        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                customer.setUrlImageIcon(String.valueOf(uri1));
                progressDialog.dismiss();
                Toast.makeText(mainActivity,"Cập Nhật Ảnh Đại Diện Thành Công",Toast.LENGTH_LONG).show();
            });
        });

    }

    //Ham dat ten cho file anh khi upload len Storage.
    private String getFileExtension(Uri mUri) {
        ContentResolver cr = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));
    }

}