package com.example.admin.Pet;

import static android.app.Activity.RESULT_OK;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.admin.Main.MainActivity;
import com.example.admin.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;


public class PhotoEditPetBanFragment extends Fragment {


    private MainActivity mainActivity;

    private View PhotoEditPetBanView;

    private Button btnAdd;
    private Button btnCancel;



    private Uri uriImageIcon;
    private Uri uriImage1;
    private Uri uriImage2;
    private Uri uriImage3;

    private Uri uriImageIcon_re;
    private Uri uriImage1_re;
    private Uri uriImage2_re;
    private Uri uriImage3_re;

    private ImageView ivImg;
    private ImageView ivImg_add_1;
    private ImageView ivImg_add_2;
    private ImageView ivImg_add_3;

    PetBan newPetBan;

    String urlImage,urlImage1,urlImage2,urlImage3;

    ArrayList<String> listUrlImage, listUrlImage1, listUrlImage2, listUrlImage3;

    private ProgressDialog progressDialog;


    public PhotoEditPetBanFragment() {
        // Required empty public constructor
    }


    public static PhotoEditPetBanFragment getInstance(PetBan petban){
        PhotoEditPetBanFragment photoEditPetBanFragment = new PhotoEditPetBanFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_photopetban", petban);
        photoEditPetBanFragment.setArguments(bundle);
        return photoEditPetBanFragment;
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        PhotoEditPetBanView =  inflater.inflate(R.layout.fragment_photo_edit_pet_ban, container, false);
        mainActivity = (MainActivity) getActivity();

        //Ánh xạ view
        initUI();

        return PhotoEditPetBanView;
    }

    private void initUI() {

        listUrlImage = new ArrayList<>();
        listUrlImage1 = new ArrayList<>();
        listUrlImage2 = new ArrayList<>();
        listUrlImage3 = new ArrayList<>();

        progressDialog = new ProgressDialog(mainActivity);

        btnAdd = PhotoEditPetBanView.findViewById(R.id.btnAdd);
        btnCancel = PhotoEditPetBanView.findViewById(R.id.btnCancel);

        ivImg = PhotoEditPetBanView.findViewById(R.id.ivImg);

        ivImg_add_1 = PhotoEditPetBanView.findViewById(R.id.ivImg_add_1);
        ivImg_add_2 = PhotoEditPetBanView.findViewById(R.id.ivImg_add_2);
        ivImg_add_3 = PhotoEditPetBanView.findViewById(R.id.ivImg_add_3);

        newPetBan = (PetBan) getArguments().get("object_photopetban");


        Glide.with(mainActivity).load(newPetBan.getUrlImageIcon()).into(ivImg);
        Glide.with(mainActivity).load(newPetBan.getUrlImage1()).into(ivImg_add_1);
        Glide.with(mainActivity).load(newPetBan.getUrlImage2()).into(ivImg_add_2);
        Glide.with(mainActivity).load(newPetBan.getUrlImage3()).into(ivImg_add_3);


        urlImage = newPetBan.getUrlImageIcon();
        urlImage1 = newPetBan.getUrlImage1();
        urlImage2 = newPetBan.getUrlImage2();
        urlImage3 = newPetBan.getUrlImage3();

        listUrlImage.add(urlImage);
        listUrlImage1.add(urlImage1);
        listUrlImage2.add(urlImage2);
        listUrlImage3.add(urlImage3);


        //Lay anh tu dien thoai up len ImageView co id la ivImg.
        ivImg.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 2);
        });

        //Lay anh tu dien thoai up len ImageView co id la ivImg_add_1.
        ivImg_add_1.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 3);
        });

        //Lay anh tu dien thoai up len ImageView co id la ivImg_add_2.
        ivImg_add_2.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 4);
        });

        //Lay anh tu dien thoai up len ImageView co id la ivImg_add_3.
        ivImg_add_3.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 5);
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();

                if(!newPetBan.getUrlImageIcon().equals(urlImage)){
                    for(int ck1 = 0; ck1 < listUrlImage.size()-1; ck1++){
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage.get(ck1));
                        storageReference.delete();
                    }
                    urlImage = newPetBan.getUrlImageIcon();
                }

                if(!newPetBan.getUrlImage1().equals(urlImage1)){
                    for(int ck2 = 0; ck2 < listUrlImage1.size()-1; ck2++){
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage1.get(ck2));
                        storageReference.delete();
                    }
                    urlImage1 = newPetBan.getUrlImage1();
                }

                if(!newPetBan.getUrlImage2().equals(urlImage2)){
                    for(int ck3 = 0; ck3 < listUrlImage2.size()-1; ck3++){
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage2.get(ck3));
                        storageReference.delete();
                    }
                    urlImage2 = newPetBan.getUrlImage2();
                }

                if(!newPetBan.getUrlImage3().equals(urlImage3)){
                    for(int ck4 = 0; ck4 < listUrlImage3.size()-1; ck4++) {
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage3.get(ck4));
                        storageReference.delete();
                    }
                    urlImage3 = newPetBan.getUrlImage3();
                }

                if(newPetBan.getUrlImageIcon().equals(urlImage) && newPetBan.getUrlImage1().equals(urlImage1) && newPetBan.getUrlImage2().equals(urlImage2) && newPetBan.getUrlImage3().equals(urlImage3)){
                    //Goi Database voi parent key la PetBan.
                    DatabaseReference root = FirebaseDatabase.getInstance().getReference("PetBan");
                    root.child(String.valueOf(newPetBan.getIdPet())).setValue(newPetBan);

                    progressDialog.setMessage("Đang Cập Nhật Lại Thông Tin Mới Cho Thú Cưng");
                    progressDialog.show();

                    //Doi 2 giay.
                    Handler handler = new Handler();
                    handler.postDelayed(() -> {
                        progressDialog.dismiss();

//                        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
//                        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
//                        fragmentTransaction.replace(R.id.root_view, new PetFragment());
//                        //Back lai content_frame ma van luu trang thai truoc.
//                        fragmentTransaction.addToBackStack(null);
//                        fragmentTransaction.commit();
                        Toast.makeText(mainActivity,"Cập Nhật Thành Công Đối Tượng " + newPetBan.getNameOfType(),Toast.LENGTH_LONG).show();

                        FragmentManager fmManager = getActivity().getSupportFragmentManager();
                        fmManager.popBackStack();
                        fmManager.popBackStack();
                    },2000);
                }

            }
        });

        //Khi huy thi tat ca cac anh da upload len server se duoc xoa het.
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();

                if(!newPetBan.getUrlImageIcon().equals(urlImage)){
                    for(int ck1 = 1; ck1 < listUrlImage.size(); ck1++){
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage.get(ck1));
                        storageReference.delete();
                    }
                    newPetBan.setUrlImageIcon(urlImage);
                }

                if(!newPetBan.getUrlImage1().equals(urlImage1)){
                    for(int ck2 = 1; ck2 < listUrlImage1.size(); ck2++){
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage1.get(ck2));
                        storageReference.delete();
                    }
                    newPetBan.setUrlImage1(urlImage1);
                }

                if(!newPetBan.getUrlImage2().equals(urlImage2)){
                    for(int ck3 = 1; ck3 < listUrlImage2.size(); ck3++){
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage2.get(ck3));
                        storageReference.delete();
                    }
                    newPetBan.setUrlImage2(urlImage2);
                }

                if(!newPetBan.getUrlImage3().equals(urlImage3)){
                    for(int ck4 = 1; ck4 < listUrlImage3.size(); ck4++) {
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage3.get(ck4));
                        storageReference.delete();
                    }
                    newPetBan.setUrlImage3(urlImage3);
                }

                if(newPetBan.getUrlImageIcon().equals(urlImage) && newPetBan.getUrlImage1().equals(urlImage1) && newPetBan.getUrlImage2().equals(urlImage2) && newPetBan.getUrlImage3().equals(urlImage3)) {
                    FragmentManager fmManager = getActivity().getSupportFragmentManager();
                    fmManager.popBackStack();
                    fmManager.popBackStack();
                }

            }
        });
    }


    private void uploadToFireBase0(Uri uriImage0, PetBan petban) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetBan").child(petban.getNameOfType());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage0));

        progressDialog.setMessage("Đang Cập Nhật Lại Ảnh Đại Diện Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage0).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                progressDialog.dismiss();
                petban.setUrlImageIcon(String.valueOf(uri1));
                listUrlImage.add(String.valueOf(uri1));
                Toast.makeText(mainActivity,"Cập Nhật Thành Công Ảnh Đại Diện Cho Thú Cưng.",Toast.LENGTH_LONG).show();
            });
        });

    }

    private void uploadToFireBase1(Uri uriImage1, PetBan petban) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetBan").child(petban.getNameOfType());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage1));

        progressDialog.setMessage("Đang Cập Nhật Lại Ảnh Phụ Thứ Nhất Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage1).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                progressDialog.dismiss();
                petban.setUrlImage1(String.valueOf(uri1));
                listUrlImage1.add(String.valueOf(uri1));
                Toast.makeText(mainActivity,"Cập Nhật Thành Công Ảnh Phụ Thứ Nhất Cho Thú Cưng.",Toast.LENGTH_LONG).show();

            });
        });

    }

    private void uploadToFireBase2(Uri uriImage2, PetBan petban) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetBan").child(petban.getNameOfType());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage2));


        progressDialog.setMessage("Đang Cập Nhật Lại Ảnh Phụ Thứ Hai Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage2).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                progressDialog.dismiss();
                petban.setUrlImage2(String.valueOf(uri1));
                listUrlImage2.add(String.valueOf(uri1));
                Toast.makeText(mainActivity,"Cập Nhật Thành Công Ảnh Phụ Thứ Hai Cho Thú Cưng.",Toast.LENGTH_LONG).show();

            });
        });

    }

    private void uploadToFireBase3(Uri uriImage3, PetBan petban) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetBan").child(petban.getNameOfType());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage3));


        progressDialog.setMessage("Đang Cập Nhật Lại Ảnh Phụ Thứ Ba Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage3).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                progressDialog.dismiss();
                petban.setUrlImage3(String.valueOf(uri1));
                listUrlImage3.add(String.valueOf(uri1));
                Toast.makeText(mainActivity,"Cập Nhật Thành Công Ảnh Phụ Thứ Ba Cho Thú Cưng.",Toast.LENGTH_LONG).show();

            });
        });

    }

    //Ham dat ten cho file anh khi upload len Storage.
    private String getFileExtension(Uri mUri) {
        ContentResolver cr = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));
    }


    //Ham tra ve ket qua va phan hoi de dua anh len ImageView.
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==2 && resultCode == RESULT_OK && data != null){
            uriImageIcon = data.getData();
            ivImg.setImageURI(uriImageIcon);
            uploadToFireBase0(uriImageIcon, newPetBan);
        }

        if(requestCode==3 && resultCode == RESULT_OK && data != null){
            uriImage1 = data.getData();
            ivImg_add_1.setImageURI(uriImage1);
            uploadToFireBase1(uriImage1, newPetBan);

        }

        if(requestCode==4 && resultCode == RESULT_OK && data != null){
            uriImage2 = data.getData();
            ivImg_add_2.setImageURI(uriImage2);
            uploadToFireBase2(uriImage2, newPetBan);

        }

        if(requestCode==5 && resultCode == RESULT_OK && data != null) {
            uriImage3 = data.getData();
            ivImg_add_3.setImageURI(uriImage3);
            uploadToFireBase3(uriImage3, newPetBan);
        }

    }

    //An nut add o option menu di khi o trang fragment nay.
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item=menu.findItem(R.id.btnAddCustomer);
        if(item!=null)
            item.setVisible(false);
    }

 }
