package com.example.admin.Interface;

import com.example.admin.Pet.PetBan;

public interface ClickItemPetBan {
    void onClickItemPetBan(PetBan petBan);
    void onClickDeletePetBan(PetBan petBan);
    void onClickEditPetBan(PetBan petBan);
}
