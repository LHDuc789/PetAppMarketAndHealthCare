package com.example.admin.User;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.admin.Main.MainActivity;
import com.example.admin.R;

public class ADetailCustomerFragment extends Fragment {

    private ImageView ivImg;
    private TextView tvName;
    private TextView tvAddress;
    private TextView tvEmail;
    private TextView tvPhone;
    private Button btnUpdateProfile;



    private View DetailView;
    private MainActivity mainActivity;


    public static final String TAG = ADetailCustomerFragment.class.getName();


    public ADetailCustomerFragment() {
        // Required empty public constructor
    }

    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static ADetailCustomerFragment getInstance(Customer customer){
        ADetailCustomerFragment aDetailCustomerFragment = new ADetailCustomerFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_customer",customer);
        aDetailCustomerFragment.setArguments(bundle);
        return aDetailCustomerFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        DetailView = inflater.inflate(R.layout.fragment_a_detail_customer, container, false);
        //Fragment duoc tao tu 1 activity nao do
        //Tra ve activity noi ma Fragment duoc tao.
        mainActivity = (MainActivity) getActivity();
        //Ánh xạ view
        initUI();
        return DetailView;
    }

    private void initUI() {
        ivImg = DetailView.findViewById(R.id.ivImg);
        tvName = DetailView.findViewById(R.id.tvName);
        tvAddress = DetailView.findViewById(R.id.tvAddress);
        tvEmail = DetailView.findViewById(R.id.tvEmail);
        tvPhone = DetailView.findViewById(R.id.tvPhone);
        btnUpdateProfile = DetailView.findViewById(R.id.btnUpdateProfile);



        //Lay du lieu tu object games ma truyen tu GamesActivity sang gan len cac thuoc tinh Fragment.
        Customer customer = (Customer) getArguments().get("object_customer");
        tvName.setText(customer.getName());
        tvAddress.setText(customer.getAddress());
        tvEmail.setText(customer.getEmail());
        tvPhone.setText(customer.getPhone());
        Glide.with(mainActivity).load(customer.getUrlImageIcon()).error(R.drawable.ic_defaultavatar).into(ivImg);

        btnUpdateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainActivity.sendDataToEditCustomerFragment(customer);
            }
        });
    }

    //An nut add o option menu di khi o trang fragment nay.
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item1 = menu.findItem(R.id.detailAccount);
        if(item1!=null)
            item1.setVisible(false);

        MenuItem item2 = menu.findItem(R.id.btnAddCustomer);
        if(item2!=null)
            item2.setVisible(false);
    }
}