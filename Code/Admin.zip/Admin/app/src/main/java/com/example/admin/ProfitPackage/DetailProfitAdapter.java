package com.example.admin.ProfitPackage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.admin.Interface.ClickItemPetBan;
import com.example.admin.Interface.ClickItemProfit;
import com.example.admin.ProfitPackage.Profit;
import com.example.admin.R;

import org.w3c.dom.Text;

import java.util.List;

public class DetailProfitAdapter extends RecyclerView.Adapter<DetailProfitAdapter.ViewHolder>{
    private List<DetailProfit> mDetailProfit;
    private final Context mContext;



    public DetailProfitAdapter(Context mContext, List _detailprofits){
        this.mContext = mContext;
        this.mDetailProfit = _detailprofits;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View profitView = inflater.inflate(R.layout.detailprofit_item,parent,false);
        return new ViewHolder(profitView);
    }

    @SuppressLint("DefaultLocale")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Lay ra vi tri cua thang object Games bat ki khi duoc click
        final DetailProfit detailprofit = (DetailProfit) mDetailProfit.get(position);
        if (detailprofit == null){
            return;
        }
        Glide.with(mContext).load(detailprofit.getUrlImageIcon()).into(holder.ivImg);
        holder.tvIdPetBan.setText("Mã Pet: " + detailprofit.getIdPetBan());
        holder.tvCost.setText("Giá Tiền: " + detailprofit.getCost());
        holder.tvNumber.setText("Số Lượng: " + detailprofit.getNumber());
    }

    @Override
    public int getItemCount() {
        return mDetailProfit.size();
    }





    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvIdPetBan;
        public TextView tvCost;
        public TextView tvNumber;
        public LinearLayout DetailProfitListItem;
        public ImageView ivImg;

        public ViewHolder(View itemView) {
            super(itemView);
            tvIdPetBan = itemView.findViewById(R.id.tvIdPetBan);
            tvCost = itemView.findViewById(R.id.tvCost);
            tvNumber = itemView.findViewById(R.id.tvNumber);
            ivImg = itemView.findViewById(R.id.ivImg);
            DetailProfitListItem = itemView.findViewById(R.id.DetailProfitListItem);

        }
    }
}
