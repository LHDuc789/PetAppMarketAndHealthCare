package com.example.admin.Pet;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.admin.Main.MainActivity;
import com.example.admin.R;


public class EditPetBanFragment extends Fragment {


    private MainActivity mainActivity;

    private View EditPetBanView;

    private TextView etNameOfType;
    private TextView etDes;
    private TextView etCost;

    private Button btnNext;
    private Button btnCancel;



//    public static final String TAG = EditPetBanFragment.class.getName();


    public EditPetBanFragment() {
        // Required empty public constructor
    }


    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static EditPetBanFragment getInstance(PetBan petban){
        EditPetBanFragment editPetBanFragment = new EditPetBanFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_petban", petban);
        editPetBanFragment.setArguments(bundle);
        return editPetBanFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        EditPetBanView =  inflater.inflate(R.layout.fragment_edit_pet_ban, container, false);
        mainActivity = (MainActivity) getActivity();

        //Ánh xạ view
        initUI();

        return EditPetBanView;
    }

    private void initUI() {
        etNameOfType = EditPetBanView.findViewById(R.id.etNameOfType);
        etDes = EditPetBanView.findViewById(R.id.etDes);
        etCost = EditPetBanView.findViewById(R.id.etCost);
        btnNext = EditPetBanView.findViewById(R.id.btnNext);
        btnCancel = EditPetBanView.findViewById(R.id.btnCancel);

        PetBan petban = (PetBan) getArguments().get("object_petban");

        etNameOfType.setText(petban.getNameOfType());
        etDes.setText(petban.getDes());
        etCost.setText(String.valueOf(petban.getCost()));



        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newNameOfType = etNameOfType.getText().toString().trim();
                String newCost = etCost.getText().toString().trim();
                String newDes = etDes.getText().toString().trim();

                petban.setNameOfType(newNameOfType);
                petban.setCost(Integer.parseInt(newCost));
                petban.setDes(newDes);

                mainActivity.sendDataToPhotoEditPetBanFragment(petban);
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fmManager = getActivity().getSupportFragmentManager();
                fmManager.popBackStack();
            }
        });
    }

    //An nut add o option menu di khi o trang fragment nay.
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item=menu.findItem(R.id.btnAddCustomer);
        if(item!=null)
            item.setVisible(false);
    }





}