package com.example.admin.Pet;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.example.admin.Interface.ClickItemPetBan;
import com.example.admin.Main.MainActivity;
import com.example.admin.R;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;


public class PetFragment extends Fragment {

    private View mView;
    private RecyclerView rcvPetBan;
    private MainActivity mainActivity;
    ArrayList<PetBan> petbans;
    int lastsize;
    PetBanAdapter petBanAdapter;
    private FrameLayout rootView;
    private ProgressDialog progressDialog;


    public PetFragment() {
        // Required empty public constructor
    }


//    public static PetFragment newInstance() {
//        PetFragment fragment = new PetFragment();
//        return fragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//
//        }
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_pet, container, false);
        initUi();
        getPetBanListFromRealtimeDataBase();

        return mView;
    }

    public void initUi(){
        //Khoi tao gamesActivity de su dung.
        mainActivity = (MainActivity) getActivity();
        progressDialog = new ProgressDialog(mainActivity);

//        rootView = mView.findViewById(R.id.apps_root_view);
        rcvPetBan = mView.findViewById(R.id.PetBanList);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mainActivity);
        rcvPetBan.setLayoutManager(linearLayoutManager);

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mainActivity,DividerItemDecoration.VERTICAL);
        rcvPetBan.addItemDecoration(itemDecoration);

        petbans = new ArrayList<>();

        petBanAdapter = new PetBanAdapter(mainActivity, petbans, new ClickItemPetBan() {
            @Override
            public void onClickItemPetBan(PetBan petBan) {
                mainActivity.sendDataToDetailPetBanFragment(petBan);
            }

            @Override
            public void onClickDeletePetBan(PetBan petBan) {
                deletePetBan(petBan);
            }

            @Override
            public void onClickEditPetBan(PetBan petBan) {
                mainActivity.sendDataToEditPetBanFragment(petBan);
            }
        });

        rcvPetBan.setAdapter(petBanAdapter);

        //Gan Option Menu len Fragment.
        setHasOptionsMenu(true);

    }

    public void getPetBanListFromRealtimeDataBase() {
        //Goi toi Firebase voi key parent la Games.
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("PetBan");
        DatabaseReference myRef_re = database.getReference("PetBan");

        //Lay ra phan tu cuoi cung
        myRef_re.orderByKey().limitToLast(1).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                PetBan d = snapshot.getValue(PetBan.class);
                if (d != null) {
                    //Chi lay phan so cua IdPet
                    String[] part = d.getIdPet().split("(?<=\\D)(?=\\d)");
                    lastsize = Integer.parseInt(part[1]);
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });


        //Add tat ca du lieu len firebase.
//        myRef.setValue(games, new DatabaseReference.CompletionListener() {
//            @Override
//            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
//                Toast.makeText(gamesActivity,"Add all games success",Toast.LENGTH_LONG).show();
//            }
//        });

//        //Sap xep du lieu theo key.
//        Query query = myRef.orderByKey();

        //Cach 1: Doc data tu firebase va dong thoi cap nhat lai adapter.
        myRef.addChildEventListener(new ChildEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                PetBan c = snapshot.getValue(PetBan.class);
                if (c != null) {
                    petbans.add(c);
                    petBanAdapter.notifyDataSetChanged();
                }

            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                PetBan petban = snapshot.getValue(PetBan.class);
                if(petban == null || petbans == null || petbans.isEmpty()){
                    return;
                }
                for(int i = 0; i < petbans.size(); i++) {
                    if (petban.getIdPet().equals(petbans.get(i).getIdPet())) {
                        petbans.set(i,petban);
                        break;
                    }
                }

                petBanAdapter.notifyDataSetChanged();
            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                PetBan petban = snapshot.getValue(PetBan.class);
                if(petban == null || petbans == null || petbans.isEmpty()){
                    return;
                }
                for(int i = 0; i < petbans.size(); i++) {
                    if (petban.getIdPet().equals(petbans.get(i).getIdPet())) {
                        petbans.remove(petbans.get(i));
                        break;
                    }
                }

                petBanAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.btnAddCustomer:
                //Khi bam add item thi se dua tong so luong item ton tai trong database sang AddFragment.
                mainActivity.sendDataToAddPetBanFragment(lastsize);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    private void deletePetBan(PetBan petban){
        new AlertDialog.Builder(mainActivity)
                .setTitle(getString(R.string.app_name))
                .setMessage("Bạn có chắc muốn xóa Pet này không ?")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String nameOfTypePetDelete = petban.getNameOfType();
                        progressDialog.setMessage("Đang Xóa Loài " + nameOfTypePetDelete);
                        progressDialog.show();
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("PetBan");
                        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(petban.getUrlImageIcon());
                        StorageReference storageReference1 = firebaseStorage.getReferenceFromUrl(petban.getUrlImage1());
                        StorageReference storageReference2 = firebaseStorage.getReferenceFromUrl(petban.getUrlImage2());
                        StorageReference storageReference3 = firebaseStorage.getReferenceFromUrl(petban.getUrlImage3());

                        myRef.child(petban.getIdPet()).removeValue(new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
                                //Xoa het toan bo anh trong thu muc.
                                storageReference.delete();
                                storageReference1.delete();
                                storageReference2.delete();
                                storageReference3.delete();

                                //Doi 2 giay.
                                Handler handler = new Handler();
                                handler.postDelayed(() -> {
                                    progressDialog.dismiss();
                                    Toast.makeText(mainActivity,"Đã xóa thành công loài " + nameOfTypePetDelete,Toast.LENGTH_LONG).show();
                                },2000);
                            }
                        });
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
        }
}