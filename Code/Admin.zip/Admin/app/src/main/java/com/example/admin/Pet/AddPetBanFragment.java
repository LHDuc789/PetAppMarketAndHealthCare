package com.example.admin.Pet;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.Main.MainActivity;
import com.example.admin.R;


@SuppressWarnings("ALL")
public class AddPetBanFragment extends Fragment {

    private EditText etNameOfType;
    private EditText etDes;
    private EditText etCost;
    private Button btnNext;
    private Button btnCancel;

    private MainActivity mainActivity;

    private View AddPetBanView;


    public static final String TAG = AddPetBanFragment.class.getName();

    public AddPetBanFragment() {
        // Required empty public constructor
    }

    public static AddPetBanFragment getInstance(int size){
        AddPetBanFragment addPetBanFragment = new AddPetBanFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("totalSize",size);
        addPetBanFragment.setArguments(bundle);
        return addPetBanFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        AddPetBanView =  inflater.inflate(R.layout.fragment_add_pet_ban, container, false);
        mainActivity = (MainActivity) getActivity();

        //Ánh xạ view
        initUI();
        return AddPetBanView;
    }

    private void initUI() {
        mainActivity = (MainActivity) getActivity();

        etNameOfType = AddPetBanView.findViewById(R.id.etNameOfType);
        etDes = AddPetBanView.findViewById(R.id.etDes);
        etCost = AddPetBanView.findViewById(R.id.etCost);
        btnNext = AddPetBanView.findViewById(R.id.btnNext);
        btnCancel = AddPetBanView.findViewById(R.id.btnCancel);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newNameOfType = etNameOfType.getText().toString().trim();
                String newCost = etCost.getText().toString().trim();
                String newDes = etDes.getText().toString().trim();

                if(newNameOfType.isEmpty()){
                    Toast.makeText(mainActivity,"Vui Lòng Nhập Tên Loài Thú Cưng", Toast.LENGTH_LONG).show();
                }

                else if(newCost.isEmpty()){
                    Toast.makeText(mainActivity,"Vui Lòng Nhập Giá Tiền", Toast.LENGTH_LONG).show();
                }

                else if(newDes.isEmpty()){
                    Toast.makeText(mainActivity,"Vui Lòng Nhập Mô Tả", Toast.LENGTH_LONG).show();
                }

                else{
                    int totalSize = (int) getArguments().get("totalSize");

                    PetBan newPetBan = new PetBan("", newNameOfType, Integer.parseInt(newCost), newDes, "", "", "", "");

                    if (totalSize < 10) {
                        newPetBan.setIdPet("PB0" + (totalSize + 1));
                    } else {
                        newPetBan.setIdPet("PB" + (totalSize + 1));
                    }
                    mainActivity.sendDataToAddPhotoPetBanFragment(newPetBan);
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fmManager = getActivity().getSupportFragmentManager();
                fmManager.popBackStack();
            }
        });
    }

    //An nut add o option menu di khi o trang fragment nay.
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item=menu.findItem(R.id.btnAddCustomer);
        if(item!=null)
            item.setVisible(false);
    }



}