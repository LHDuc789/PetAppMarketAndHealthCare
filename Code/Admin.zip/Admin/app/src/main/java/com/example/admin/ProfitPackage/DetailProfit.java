package com.example.admin.ProfitPackage;

import java.io.Serializable;

import java.io.Serializable;

public class DetailProfit implements Serializable {
    private String IdDesBill;
    private String IdBill;
    private String IdPetBan;
    private String UrlImageIcon;
    private int Cost;
    private int Number;

    public DetailProfit(String IdDesBill, String IdBill, String IdPetBan, String UrlImageIcon, int Cost, int Number){
        this.IdDesBill = IdDesBill;
        this.IdBill = IdBill;
        this.IdPetBan = IdPetBan;
        this.UrlImageIcon = UrlImageIcon;
        this.Cost = Cost;
        this.Number = Number;
    }

    public DetailProfit(){

    }

    public String getIdDesBill() {
        return IdDesBill;
    }

    public void setIdDesBill(String idDesBill) {
        IdDesBill = idDesBill;
    }

    public String getUrlImageIcon() {
        return UrlImageIcon;
    }

    public void setUrlImageIcon(String urlImageIcon) {
        UrlImageIcon = urlImageIcon;
    }

    public String getIdBill() {
        return IdBill;
    }

    public void setIdBill(String idBill) {
        IdBill = idBill;
    }

    public String getIdPetBan() {
        return IdPetBan;
    }

    public void setIdPetBan(String idPetBan) {
        IdPetBan = idPetBan;
    }

    public int getCost() {
        return Cost;
    }

    public void setCost(int cost) {
        Cost = cost;
    }

    public int getNumber() {
        return Number;
    }

    public void setNumber(int number) {
        Number = number;
    }
}
