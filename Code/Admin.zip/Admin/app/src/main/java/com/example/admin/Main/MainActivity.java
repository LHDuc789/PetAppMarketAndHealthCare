package com.example.admin.Main;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.admin.Pet.AddPetBanFragment;
import com.example.admin.Pet.AddPhotoPetBanFragment;
import com.example.admin.Pet.DetailPetBanFragment;
import com.example.admin.Pet.EditPetBanFragment;
import com.example.admin.Pet.PetBan;
import com.example.admin.Pet.PhotoEditPetBanFragment;
import com.example.admin.ProfitPackage.DetailProfitFragment;
import com.example.admin.ProfitPackage.Profit;
import com.example.admin.R;
import com.example.admin.User.ADetailCustomerFragment;
import com.example.admin.User.AddCustomerActivity;
import com.example.admin.User.Customer;
import com.example.admin.User.DetailCustomerFragment;
import com.example.admin.User.EditCustomerFragment;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

@SuppressWarnings("deprecation")
public class MainActivity extends AppCompatActivity {

    private TabLayout mTabLayout;
    private ViewPager mViewPager;

    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressDialog = new ProgressDialog(this);

        mTabLayout = (TabLayout) findViewById(R.id.tab_layout);
        mViewPager = (ViewPager) findViewById(R.id.view_pager);

        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mViewPager.setAdapter(viewPagerAdapter);

        mTabLayout.setupWithViewPager(mViewPager);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.detailAccount:
                //Lay ra doi tuong user dang login hien tai.
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if(user == null){
                    return false;
                }
                //Lay Uid cua user hien tai.
                String Uid = user.getUid();
                //Truy cap vao User theo Uid
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("User");
                myRef.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        String UserId = snapshot.getKey();
                        assert UserId != null;
                        if(UserId.equals(Uid)){
                            Customer c = snapshot.getValue(Customer.class);
                            if (c != null) {
                                //Dua cac thong tin cua User sang fragment ADetailCustomer
                                Customer detailcustomer = new Customer(c.getIdUser(),c.getName(),c.getEmail(),c.getAddress(),c.getPhone(),c.getUrlImageIcon(), c.getCreateDate());
                                sendDataToDetailACustomerFragment(detailcustomer);
                            }
                        }

                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                return true;
            case R.id.logoutAccount:

                new AlertDialog.Builder(this)
                        .setTitle(getString(R.string.app_name))
                        .setMessage("Quá Trình Này Sẽ Khiến Bạn Đăng Xuất Khỏi Tài Khoản Hiện Tại.")
                        .setPositiveButton("Đồng Ý", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                progressDialog.setMessage("Đang Đăng Xuất Tài Khoản Hiện Tại.");
                                progressDialog.show();
                                Handler handler = new Handler();
                                handler.postDelayed(() -> {
                                    progressDialog.dismiss();
//                        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
//                        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
//                        fragmentTransaction.replace(R.id.root_view, new PetFragment());
//                        //Back lai content_frame ma van luu trang thai truoc.
//                        fragmentTransaction.addToBackStack(null);
//                        fragmentTransaction.commit();
                                    Toast.makeText(MainActivity.this,"Đăng Xuất Tài Khoản Thành Công.",Toast.LENGTH_LONG).show();
                                    FirebaseAuth.getInstance().signOut();
                                    Intent intent = new Intent(MainActivity.this, SignInActivity.class);
                                    startActivity(intent);
                                    finish();
                                },1000);
                            }
                        })
                        .setNegativeButton("Không Đồng Ý", null)
                        .show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void sendDataToDetailFragment(Customer customer) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, DetailCustomerFragment.getInstance(customer));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(DetailCustomerFragment.TAG);
        fragmentTransaction.commit();
    }

    public void sendDataToDetailACustomerFragment(Customer customer) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, ADetailCustomerFragment.getInstance(customer));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(ADetailCustomerFragment.TAG);
        fragmentTransaction.commit();
    }

    public void sendDataToEditCustomerFragment(Customer customer) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, EditCustomerFragment.getInstance(customer));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void sendDataToDetailPetBanFragment(PetBan petban) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, DetailPetBanFragment.getInstance(petban));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(DetailPetBanFragment.TAG);
        fragmentTransaction.commit();
    }

    public void sendDataToAddCustomerActivity(int size){
        Intent intent = new Intent(MainActivity.this, AddCustomerActivity.class);
        intent.putExtra("totalSize", size);
        startActivity(intent);
    }

    public void sendDataToAddPetBanFragment(int size) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, AddPetBanFragment.getInstance(size));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void sendDataToAddPhotoPetBanFragment(PetBan petban) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, AddPhotoPetBanFragment.getInstance(petban));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void sendDataToEditPetBanFragment(PetBan petBan) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, EditPetBanFragment.getInstance(petBan));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void sendDataToPhotoEditPetBanFragment(PetBan petBan) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, PhotoEditPetBanFragment.getInstance(petBan));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void sendDataToDetailProfitFragment(Profit profit) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, DetailProfitFragment.getInstance(profit));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }





    @Override
    public void onBackPressed() {

        int count = getSupportFragmentManager().getBackStackEntryCount();
        if(count == 0){
            super.onBackPressed();
        }
        else{
            getSupportFragmentManager().popBackStack();
        }
    }



}