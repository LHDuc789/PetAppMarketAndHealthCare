package com.example.admin.User;

import java.io.Serializable;

public class Customer implements Serializable {
    private String IdUser;
    private String Name;
    private String Phone;
    private String Email;
    private String Address;
    private String CreateDate;
    private String UrlImageIcon;


    public Customer(){

    }

    public Customer(String Name, String Email){
        this.Name = Name;
        this.Email = Email;
    }

    public Customer(String IdUser, String Name, String Email, String Address, String Phone, String UrlImageIcon, String CreateDate){
        this.IdUser = IdUser;
        this.Name = Name;
        this.Email = Email;
        this.Address = Address;
        this.Phone = Phone;
        this.UrlImageIcon = UrlImageIcon;
        this.CreateDate = CreateDate;
    }

    public String getIdUser() {
        return IdUser;
    }

    public void setIdUser(String idUser) {
        IdUser = idUser;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(String createDate) {
        CreateDate = createDate;
    }

    public String getUrlImageIcon() {
        return UrlImageIcon;
    }

    public void setUrlImageIcon(String urlImageIcon) {
        UrlImageIcon = urlImageIcon;
    }
}
