package com.example.admin.ProfitPackage;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.Interface.ClickItemProfit;
import com.example.admin.Main.MainActivity;
import com.example.admin.Pet.DetailPetBanFragment;
import com.example.admin.Pet.PetBan;
import com.example.admin.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


public class DetailProfitFragment extends Fragment {

    private View mView;
    private RecyclerView rcvDetailProfit;
    private MainActivity mainActivity;
    ArrayList<DetailProfit> detailProfits;
    DetailProfitAdapter detailProfitAdapter;
    private FrameLayout rootView;
    private TextView total;
    private TextView tvNameBill;
    private ProgressDialog progressDialog;


    private int t = 0;
    Profit profit;

    public DetailProfitFragment() {
        // Required empty public constructor
    }


    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static DetailProfitFragment getInstance(Profit profit){
        DetailProfitFragment detailProfitFragment = new DetailProfitFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_profit", profit);
        detailProfitFragment.setArguments(bundle);
        return detailProfitFragment;
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_detail_profit, container, false);
        initUi();
        getDetailProfitListFromRealtimeDataBase();

        tvNameBill.setText("Hóa Đơn: " + profit.getIdBill());

        return mView;
    }



    private void initUi() {
        //Khoi tao gamesActivity de su dung.
        mainActivity = (MainActivity) getActivity();

        profit = (Profit) getArguments().get("object_profit");


//        rootView = mView.findViewById(R.id.apps_root_view);
        rcvDetailProfit = mView.findViewById(R.id.DetailProfitList);
        total = mView.findViewById(R.id.tvTotal);
        Button btnConfirm = mView.findViewById(R.id.btnConfirm);
        progressDialog = new ProgressDialog(mainActivity);

        tvNameBill = mView.findViewById(R.id.tvNameBill);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mainActivity);
        rcvDetailProfit.setLayoutManager(linearLayoutManager);

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mainActivity,DividerItemDecoration.VERTICAL);
        rcvDetailProfit.addItemDecoration(itemDecoration);

        detailProfits = new ArrayList<>();

        detailProfitAdapter = new DetailProfitAdapter(mainActivity, detailProfits);
        rcvDetailProfit.setAdapter(detailProfitAdapter);

        if(profit.getStatus().equals("True")){
            btnConfirm.setVisibility(View.GONE);
        }
        else{
            btnConfirm.setVisibility(View.VISIBLE);
        }
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(mainActivity)
                        .setTitle("Xác Nhận Thanh Toán")
                        .setMessage("Xác Nhận Thanh Toán Cho Hóa Đơn Này ?")
                        .setPositiveButton("Đồng Ý", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                progressDialog.setMessage("Đang Xác Nhận.");
                                progressDialog.show();

                                profit.setStatus("True");
                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference myRef = database.getReference("Bill");
                                myRef.child(profit.getIdBill()).setValue(profit);

                                Handler handler = new Handler();
                                handler.postDelayed(() -> {
                                    progressDialog.dismiss();
                                    Toast.makeText(mainActivity, "Hoàn Tất Thanh Toán", Toast.LENGTH_LONG).show();
                                    FragmentManager fmManager = getActivity().getSupportFragmentManager();
                                    fmManager.popBackStack();
                                }, 2000);
                            }
                        })
                        .setNegativeButton("Không", null)
                        .show();
            }
        });
    }

    private void getDetailProfitListFromRealtimeDataBase() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("DesBill");
//        Query query = myRef.orderByChild("IdBill").equalTo(profit.getIdBill());

        //Cach 1: Doc data tu firebase va dong thoi cap nhat lai adapter.
        myRef.addChildEventListener(new ChildEventListener() {
            @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                DetailProfit c = snapshot.getValue(DetailProfit.class);
                if (c != null) {
                    if(c.getIdBill().equals(profit.getIdBill())){
                        detailProfits.add(c);
                        t = t + c.getNumber()*c.getCost();
                        detailProfitAdapter.notifyDataSetChanged();
                    }
                    total.setText("Tổng Cộng: " + t);

                }


            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    //An nut add o option menu di khi o trang fragment nay.
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item=menu.findItem(R.id.btnAddCustomer);
        if(item!=null)
            item.setVisible(false);
    }
}
