package com.example.admin.Main;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.R;
import com.example.admin.User.AddCustomerActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

public class SignInActivity extends AppCompatActivity {

//    private LinearLayout layoutSignUp;
//    private TextView tvSignUp;
    private Button btnSignIn;
    private EditText SignInEmail;
    private EditText SignInPassword;

    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        initUi();
        initListener();
    }



    private void initUi() {
        progressDialog = new ProgressDialog(this);
//        layoutSignUp = findViewById(R.id.layout_sign_up);
//        tvSignUp = findViewById(R.id.tvSignUp);
        btnSignIn = findViewById(R.id.btnSignIn);
        SignInEmail = findViewById(R.id.SignInEmail);
        SignInPassword = findViewById(R.id.SignInPassword);
    }

    private void initListener() {
//        tvSignUp.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(SignInActivity.this, AddCustomerActivity.class);
//                startActivity(intent);
//            }
//        });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickSignIn();
            }
        });


    }

    private void onClickSignIn() {
        String email = SignInEmail.getText().toString().trim();
        String password = SignInPassword.getText().toString().trim();

        if(TextUtils.isEmpty(email)){
            Toast.makeText(SignInActivity.this, "Vui Lòng Nhập Địa Chỉ Email.",
                    Toast.LENGTH_SHORT).show();
        }

        else if(TextUtils.isEmpty(password)){
            Toast.makeText(SignInActivity.this, "Vui Lòng Nhập Mật Khẩu.",
                    Toast.LENGTH_SHORT).show();
        }


        else {
            FirebaseAuth auth = FirebaseAuth.getInstance();
            progressDialog.setMessage("Đang Đăng Nhập.");
            progressDialog.show();
            auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            progressDialog.dismiss();
                            if (task.isSuccessful()) {
                                Toast.makeText(SignInActivity.this, "Đăng Nhập Thành Công",
                                        Toast.LENGTH_SHORT).show();
                                // Sign in success, update UI with the signed-in user's information
                                Intent intent = new Intent(SignInActivity.this,MainActivity.class);
                                startActivity(intent);
                                finishAffinity();
                            } else {
                                try
                                {
                                    throw task.getException();
                                }
                                // if user enters wrong email.
                                catch (FirebaseAuthInvalidUserException invalidEmail)
                                {
                                    Toast.makeText(SignInActivity.this, "Email Này Không Tồn Tại.",
                                            Toast.LENGTH_SHORT).show();
                                }
                                // if user enters wrong password.
                                catch (FirebaseAuthInvalidCredentialsException wrongPassword)
                                {
                                    Toast.makeText(SignInActivity.this, "Mật Khẩu Không Chính Xác.",
                                            Toast.LENGTH_SHORT).show();
                                }
                                catch (Exception e)
                                {
                                    Toast.makeText(SignInActivity.this, "Đăng Nhập Thất Bại.",
                                            Toast.LENGTH_SHORT).show();
                                }

                            }
                        }
                    });
        }
    }
}