package com.example.admin.ProfitPackage;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.example.admin.Interface.ClickItemPetBan;
import com.example.admin.Interface.ClickItemProfit;
import com.example.admin.Main.MainActivity;
import com.example.admin.Pet.PetBan;
import com.example.admin.Pet.PetBanAdapter;
import com.example.admin.R;
import com.example.admin.User.Customer;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


public class ProfitFragment extends Fragment {

    private View mView;
    private RecyclerView rcvProfit;
    private MainActivity mainActivity;
    ArrayList<Profit> profits;
    ProfitAdapter profitAdapter;
    private FrameLayout rootView;
    private TextView total;
    private int t = 0;
    private int count = 0;


    public ProfitFragment() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_profit, container, false);
        initUi();
        getProfitListFromRealtimeDataBase();

        return mView;
    }



    private void initUi() {

        //Khoi tao gamesActivity de su dung.
        mainActivity = (MainActivity) getActivity();

//        rootView = mView.findViewById(R.id.apps_root_view);
        rcvProfit = mView.findViewById(R.id.ProfitList);

        total = mView.findViewById(R.id.tvTotal);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mainActivity);
        rcvProfit.setLayoutManager(linearLayoutManager);

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mainActivity,DividerItemDecoration.VERTICAL);
        rcvProfit.addItemDecoration(itemDecoration);

        profits = new ArrayList<>();

        profitAdapter = new ProfitAdapter(mainActivity, profits, new ClickItemProfit() {
            @Override
            public void onClickItemProfit(Profit profit) {
                mainActivity.sendDataToDetailProfitFragment(profit);
            }
        });
        rcvProfit.setAdapter(profitAdapter);

    }


    private void getProfitListFromRealtimeDataBase() {

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Bill");

        //Cach 1: Doc data tu firebase va dong thoi cap nhat lai adapter.
        myRef.addChildEventListener(new ChildEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Profit c = snapshot.getValue(Profit.class);
                if (c != null) {
                    profits.add(c);
                    profitAdapter.notifyDataSetChanged();
                    if(c.getStatus().equals("True")){
                        DatabaseReference myRefDetail = database.getReference("DesBill");
                        myRefDetail.addChildEventListener(new ChildEventListener() {
                            @SuppressLint("SetTextI18n")
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                DetailProfit desBill = snapshot.getValue(DetailProfit.class);
                                if (desBill != null) {
                                    if(desBill.getIdBill().equals(c.getIdBill())){
                                        t = t + desBill.getNumber()*desBill.getCost();
                                    }
                                }
                                total.setText("Tổng Cộng: " + t);
                            }
                            @Override
                            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                }

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Profit profit = snapshot.getValue(Profit.class);
                if(profit == null || profits == null || profits.isEmpty()){
                    return;
                }
                for(int i = 0; i < profits.size(); i++) {
                    if (profit.getIdBill().equals(profits.get(i).getIdBill())) {
                        profits.set(i,profit);

                        count = i;

                        DatabaseReference myRefDetail = database.getReference("DesBill");
                        myRefDetail.addChildEventListener(new ChildEventListener() {
                            @SuppressLint("SetTextI18n")
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                DetailProfit desBill = snapshot.getValue(DetailProfit.class);
                                if (desBill != null) {
                                    if(desBill.getIdBill().equals(profits.get(count).getIdBill())){
                                        t = t + desBill.getNumber()*desBill.getCost();
                                    }
                                }
                                total.setText("Tổng Cộng: " + t);
                            }
                            @Override
                            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });


                        break;
                    }
                }

                profitAdapter.notifyDataSetChanged();
            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    //An nut add o option menu di khi o trang fragment nay.
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item=menu.findItem(R.id.btnAddCustomer);
        if(item!=null)
            item.setVisible(false);
    }
}