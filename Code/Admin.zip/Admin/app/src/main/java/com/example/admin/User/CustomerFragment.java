package com.example.admin.User;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.Interface.ClickItemCustomer;
import com.example.admin.Main.MainActivity;
import com.example.admin.R;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


public class CustomerFragment extends Fragment{
    private View mView;
    private RecyclerView rcvCustomer;
    private MainActivity mainActivity;
    ArrayList<Customer> customers;
    CustomerAdapter customerAdapter;
    private FrameLayout rootView;
    int lastsize;




    public CustomerFragment() {
        // Required empty public constructor
    }


//    public static CustomerFragment newInstance() {
//        CustomerFragment fragment = new CustomerFragment();
//        return fragment;
//    }

//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//
//        }
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_customer, container, false);
        initUi();
        getCustomerListFromRealtimeDataBase();

        return mView;
    }

    public void initUi(){
        //Khoi tao gamesActivity de su dung.
        mainActivity = (MainActivity) getActivity();

//        rootView = mView.findViewById(R.id.apps_root_view);
        rcvCustomer = mView.findViewById(R.id.CustomerList);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mainActivity);
        rcvCustomer.setLayoutManager(linearLayoutManager);

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mainActivity,DividerItemDecoration.VERTICAL);
        rcvCustomer.addItemDecoration(itemDecoration);

        customers = new ArrayList<>();

        customerAdapter = new CustomerAdapter(mainActivity, customers, new ClickItemCustomer() {
            @Override
            public void onClickItemCustomer(Customer customer) {
                mainActivity.sendDataToDetailFragment(customer);
            }

            @Override
            public void onClickDeleteCustomer(Customer customer) {

            }
        });

        rcvCustomer.setAdapter(customerAdapter);

        //Gan Option Menu len Fragment.
        setHasOptionsMenu(true);

    }

    public void getCustomerListFromRealtimeDataBase() {
        //Goi toi Firebase voi key parent la Games.
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("User");
        DatabaseReference myRef_re = database.getReference("User");

        //Lay ra phan tu cuoi cung
        myRef_re.orderByChild("idUser").limitToLast(1).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Customer d = snapshot.getValue(Customer.class);
                if (d != null) {
                    if(!d.getIdUser().equals("Admin")){
                        //Chi lay phan so cua IdPet
                        String[] part = d.getIdUser().split("(?<=\\D)(?=\\d)");
                        lastsize = Integer.parseInt(part[1]);
                    }
                    else{
                        lastsize = 1;
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });

        //Add tat ca du lieu len firebase.
//        myRef.setValue(games, new DatabaseReference.CompletionListener() {
//            @Override
//            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
//                Toast.makeText(gamesActivity,"Add all games success",Toast.LENGTH_LONG).show();
//            }
//        });

//        //Sap xep du lieu theo key.
//        Query query = myRef.orderByKey();

        //Cach 1: Doc data tu firebase va dong thoi cap nhat lai adapter.
        myRef.orderByChild("createDate").addChildEventListener(new ChildEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Customer c = snapshot.getValue(Customer.class);
                if (c != null) {
                    if(!c.getIdUser().equals("Admin")) {
                        customers.add(c);
                        customerAdapter.notifyDataSetChanged();
                    }
                }

            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Customer customer = snapshot.getValue(Customer.class);
                if(customer == null || customers == null || customers.isEmpty()){
                    return;
                }
                for(int i = 0; i < customers.size(); i++) {
                    if (customer.getIdUser().equals(customers.get(i).getIdUser())) {
                        customers.set(i,customer);
                        break;
                    }
                }

                customerAdapter.notifyDataSetChanged();
            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                Customer customer = snapshot.getValue(Customer.class);
                if(customer == null || customers == null || customers.isEmpty()){
                    return;
                }
                for(int i = 0; i < customers.size(); i++) {
                    if (customer.getIdUser().equals(customers.get(i).getIdUser())) {
                        customers.remove(customers.get(i));
                        break;
                    }
                }

                customerAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }




    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.btnAddCustomer:
                //Khi bam add item thi se dua tong so luong item ton tai trong database sang AddFragment.
                mainActivity.sendDataToAddCustomerActivity(lastsize);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

//    private void onClickDeleteCustomer(Customer customer){
//        new AlertDialog.Builder(mainActivity)
//                .setTitle(getString(R.string.app_name))
//                .setMessage("Bạn có chắc muốn xóa Customer này không ?")
//                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        FirebaseDatabase database = FirebaseDatabase.getInstance();
//                        DatabaseReference myRef = database.getReference("User");
//                        myRef.child(customer.getIdUser()).removeValue(new DatabaseReference.CompletionListener() {
//                            @Override
//                            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
//                                Toast.makeText(mainActivity,"Đã xóa thành công customer này",Toast.LENGTH_LONG).show();
//                            }
//                        });
//                    }
//                })
//                .setNegativeButton("Cancel", null)
//                .show();
//        }
    }
