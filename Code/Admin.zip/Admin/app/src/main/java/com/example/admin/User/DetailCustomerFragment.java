package com.example.admin.User;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.admin.Main.MainActivity;
import com.example.admin.R;

public class DetailCustomerFragment extends Fragment {

    private ImageView ivImg;
    private TextView tvName;
    private TextView tvAddress;
    private TextView tvEmail;
    private TextView tvPhone;


    private View DetailView;
    private MainActivity mainActivity;


    public static final String TAG = DetailCustomerFragment.class.getName();


    public DetailCustomerFragment() {
        // Required empty public constructor
    }



    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static DetailCustomerFragment getInstance(Customer customer){
        DetailCustomerFragment detailCustomerFragment = new DetailCustomerFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_customer",customer);
        detailCustomerFragment.setArguments(bundle);
        return detailCustomerFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setHasOptionsMenu(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        DetailView = inflater.inflate(R.layout.fragment_detail_customer, container, false);
        //Fragment duoc tao tu 1 activity nao do
        //Tra ve activity noi ma Fragment duoc tao.
        mainActivity = (MainActivity) getActivity();
        //Ánh xạ view
        initUI();
        return DetailView;
    }

    private void initUI() {
        ivImg = DetailView.findViewById(R.id.ivImg);
        tvName = DetailView.findViewById(R.id.tvName);
        tvAddress = DetailView.findViewById(R.id.tvAddress);
        tvEmail = DetailView.findViewById(R.id.tvEmail);
        tvPhone = DetailView.findViewById(R.id.tvPhone);


        //Lay du lieu tu object games ma truyen tu GamesActivity sang gan len cac thuoc tinh Fragment.
        Customer customer = (Customer) getArguments().get("object_customer");
        tvName.setText(customer.getName());
        tvAddress.setText(customer.getAddress());
        tvEmail.setText(customer.getEmail());
        tvPhone.setText(customer.getPhone());
        Glide.with(mainActivity).load(customer.getUrlImageIcon()).into(ivImg);


    }
}