package com.example.admin.HomePackage;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.admin.Main.MainActivity;
import com.example.admin.R;
import com.example.admin.User.Customer;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class HomeFragment extends Fragment {

    private View mView;

    private TextView tvName;
    private ImageView ivImg;
    private MainActivity mainActivity;



    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    //Hàm này code đổ dữ liệu, tương tự cho 3 thằng fragment kia
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_home, container, false);
        mainActivity = (MainActivity) getActivity();

        initUi();
        initName();
        return mView;
    }

    private void initUi() {
        tvName = mView.findViewById(R.id.tvName);
        ivImg = mView.findViewById(R.id.ivImg);
    }

    private void initName() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        //Lay Uid cua user hien tai.
        String Uid = user.getUid();
        //Truy cap vao User theo Uid
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("User").child(Uid);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                tvName.setText(snapshot.child("name").getValue(String.class));
                Glide.with(mainActivity).load(snapshot.child("urlImageIcon").getValue(String.class)).error(R.drawable.ic_admin_home).into(ivImg);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    //An nut add o option menu di khi o trang fragment nay.
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item=menu.findItem(R.id.btnAddCustomer);
        if(item!=null)
            item.setVisible(false);
    }
}