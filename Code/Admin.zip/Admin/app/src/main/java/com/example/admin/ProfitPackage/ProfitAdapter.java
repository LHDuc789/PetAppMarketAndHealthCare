package com.example.admin.ProfitPackage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.admin.Interface.ClickItemPetBan;
import com.example.admin.Interface.ClickItemProfit;
import com.example.admin.ProfitPackage.Profit;
import com.example.admin.R;

import org.w3c.dom.Text;

import java.util.List;

public class ProfitAdapter extends RecyclerView.Adapter<ProfitAdapter.ViewHolder>{
    private final List<Profit> mProfit;
    private final Context mContext;
    private final ClickItemProfit clickItemProfitListener;


    public ProfitAdapter(Context mContext,List _profits, ClickItemProfit listener){
        this.mContext = mContext;
        this.mProfit = _profits;
        this.clickItemProfitListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View profitView = inflater.inflate(R.layout.profit_item,parent,false);
        return new ViewHolder(profitView);
    }

    @SuppressLint({"DefaultLocale", "SetTextI18n"})
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Lay ra vi tri cua thang object Games bat ki khi duoc click
        final Profit profit = (Profit) mProfit.get(position);
        if (profit == null){
            return;
        }

        holder.tvIdBill.setText("Mã Hóa Đơn: " + profit.getIdBill());
        holder.tvIdUser.setText("Mã User: " + profit.getIdUser());
        holder.tvName.setText("Tên Người Mua: " + profit.getName());
        holder.tvPhone.setText("Số Điện Thoại: " + profit.getPhone());
        holder.tvAddress.setText("Địa Chỉ: " + profit.getAddress());
        holder.tvEmail.setText("Email: " + profit.getEmail());
        holder.tvCreateDate.setText("Ngày Tạo: " + profit.getCreateDate());
        if (profit.getStatus().equals("False")){
            holder.tvStatus.setText("Chưa Thanh Toán");
            holder.tvStatus.setTextColor(Color.parseColor("#C11407"));
        }
        else{
            holder.tvStatus.setText("Đã Thanh Toán");
            holder.tvStatus.setTextColor(Color.parseColor("#5F9F14"));
        }
        holder.ProfitListItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickItemProfitListener.onClickItemProfit(profit);
            }
        });


    }

    @Override
    public int getItemCount() {
        return mProfit.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvIdBill;
        public TextView tvIdUser;
        public LinearLayout ProfitListItem;
        public TextView tvCreateDate;
        public TextView tvStatus;
        public TextView tvName;
        public TextView tvPhone;
        public TextView tvAddress;
        public TextView tvEmail;


        public ViewHolder(View itemView) {
            super(itemView);
            tvIdBill = itemView.findViewById(R.id.tvIdBill);
            tvIdUser = itemView.findViewById(R.id.tvIdUser);
            tvCreateDate = itemView.findViewById(R.id.tvCreateDate);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            ProfitListItem = itemView.findViewById(R.id.ProfitListItem);
            tvName = itemView.findViewById(R.id.tvName);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvAddress = itemView.findViewById(R.id.tvAddress);
            tvEmail = itemView.findViewById(R.id.tvEmail);
        }
    }
}
