package com.example.admin.User;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.admin.Interface.ClickItemCustomer;
import com.example.admin.R;

import java.util.List;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.ViewHolder>{
    private List<Customer> mCustomer;
    private final Context mContext;
    private final ClickItemCustomer clickItemCustomerListener;


    public CustomerAdapter(Context mContext,List _customers, ClickItemCustomer listener){
        this.mContext = mContext;
        this.mCustomer = _customers;
        this.clickItemCustomerListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View customerView = inflater.inflate(R.layout.customer_item,parent,false);
        return new ViewHolder(customerView);
    }

    @SuppressLint("DefaultLocale")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Lay ra vi tri cua thang object Games bat ki khi duoc click
        final Customer customer = (Customer) mCustomer.get(position);
        if (customer == null){
            return;
        }

        holder.tvName.setText(customer.getName());
        holder.tvAddress.setText(customer.getAddress());

        //Su dung thu vien Glide de load anh lay tu firebase ve.
        Glide.with(mContext).load(customer.getUrlImageIcon()).into(holder.ivImg);
//        holder.ivImg.setImageResource(games.getImg());

        holder.CustomerListItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickItemCustomerListener.onClickItemCustomer(customer);
            }
        });



    }

    @Override
    public int getItemCount() {
        return mCustomer.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvName;
        public TextView tvAddress;
        public ImageView ivImg;
        public LinearLayout CustomerListItem;


        public ViewHolder(View itemView) {
            super(itemView);
            ivImg = itemView.findViewById(R.id.ivImg);
            tvName = itemView.findViewById(R.id.tvName);
            tvAddress = itemView.findViewById(R.id.tvAddress);
            CustomerListItem = itemView.findViewById(R.id.CustomerListItem);

        }
    }
}
