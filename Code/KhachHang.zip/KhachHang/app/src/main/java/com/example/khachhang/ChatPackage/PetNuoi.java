package com.example.khachhang.ChatPackage;

import java.io.Serializable;

public class PetNuoi implements Serializable {
    private String IdPet;
    private String IdUser;
    private String NamePet;
    private String NameOfType;
    private String UrlImageIcon;
    private boolean CheckLike;
    private int TotalLike;

    public PetNuoi(){
    }

    public PetNuoi(String idPet) {
        IdPet = idPet;
    }

    public String getIdPet() {
        return IdPet;
    }

    public void setIdPet(String idPet) {
        IdPet = idPet;
    }

    public String getIdUser() {
        return IdUser;
    }

    public void setIdUser(String idUser) {
        IdUser = idUser;
    }

    public String getNamePet() {
        return NamePet;
    }

    public void setNamePet(String namePet) {
        NamePet = namePet;
    }

    public String getNameOfType() {
        return NameOfType;
    }

    public void setNameOfType(String nameOfType) {
        NameOfType = nameOfType;
    }

    public String getUrlImageIcon() {
        return UrlImageIcon;
    }

    public void setUrlImageIcon(String urlImageIcon) {
        UrlImageIcon = urlImageIcon;
    }

    public boolean isCheckLike() {
        return CheckLike;
    }

    public void setCheckLike(boolean checkLike) {
        CheckLike = checkLike;
    }

    public int getTotalLike() {
        return TotalLike;
    }

    public void setTotalLike(int totalLike) {
        TotalLike = totalLike;
    }
}
