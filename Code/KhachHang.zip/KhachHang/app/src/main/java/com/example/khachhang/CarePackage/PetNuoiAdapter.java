package com.example.khachhang.CarePackage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.khachhang.Interface.ClickItemPetNuoi;
import com.example.khachhang.R;

import java.util.List;

public class PetNuoiAdapter extends RecyclerView.Adapter<PetNuoiAdapter.ViewHolder>{
    private List<PetNuoi> mPetNuoi;
    private final Context mContext;
    private final ClickItemPetNuoi clickItemPetNuoiListener;


    public PetNuoiAdapter(Context mContext,List _petbans, ClickItemPetNuoi listener){
        this.mContext = mContext;
        this.mPetNuoi = _petbans;
        this.clickItemPetNuoiListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View petnuoiView = inflater.inflate(R.layout.item_care,parent,false);
        return new ViewHolder(petnuoiView);
    }

    @SuppressLint({"DefaultLocale", "SetTextI18n"})
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Lay ra vi tri cua thang object Games bat ki khi duoc click
        final PetNuoi petnuoi = (PetNuoi) mPetNuoi.get(position);
        if (petnuoi == null){
            return;
        }

        holder.tvName.setText("Tên: " + petnuoi.getNamePet());
        holder.tvNameOfType.setText("Tên Loài: " + petnuoi.getNameOfType());

        //Su dung thu vien Glide de load anh lay tu firebase ve.
        Glide.with(mContext).load(petnuoi.getUrlImageIcon()).into(holder.ivImg);
//        holder.ivImg.setImageResource(games.getImg());

        holder.PetNuoiListItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickItemPetNuoiListener.onClickItemPetNuoi(petnuoi);
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickItemPetNuoiListener.onClickDeletePetNuoi(petnuoi);
            }
        });

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickItemPetNuoiListener.onClickEditPetNuoi(petnuoi);
            }
        });



    }

    @Override
    public int getItemCount() {
        return mPetNuoi.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvName;
        public TextView tvNameOfType;
        public ImageView ivImg;
        public LinearLayout PetNuoiListItem;
        public ImageButton btnEdit,btnDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            ivImg = itemView.findViewById(R.id.ivImg);
            tvName = itemView.findViewById(R.id.tvName);
            tvNameOfType = itemView.findViewById(R.id.tvNameOfType);
            PetNuoiListItem = itemView.findViewById(R.id.PetNuoiListItem);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);

        }
    }
}
