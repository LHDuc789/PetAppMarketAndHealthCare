package com.example.khachhang.CarePackage;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.R;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class DetailPetNuoiFragment extends Fragment {


    private ImageView ivImg;
    private TextView tvNamePet;
    private CheckBox cbSkin;
    private CheckBox cbClaw;
    private CheckBox cbHealth;
    private CheckBox cbFood;
    private CheckBox cbShower;

    private static final int REQUEST_POST_NOTIFICATIONS_PERMISSION = 999;


    private TextView tvCheckClaw,tvCheckSkin,tvCheckFood,tvCheckShower,tvCheckHealth;


    private View DetailView;
    private MainActivity mainActivity;

    PetNuoi petnuoi;

    String currentDateAndTime;

    int codeClaw, codeFood, codeHealth, codeSkin, codeShower;


    public static final String TAG = DetailPetNuoiFragment.class.getName();


    public DetailPetNuoiFragment() {
        // Required empty public constructor
    }

    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static DetailPetNuoiFragment getInstance(PetNuoi petnuoi){
        DetailPetNuoiFragment detailPetNuoiFragment = new DetailPetNuoiFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_petnuoi", petnuoi);
        detailPetNuoiFragment.setArguments(bundle);
        return detailPetNuoiFragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        DetailView = inflater.inflate(R.layout.fragment_detail_pet_nuoi, container, false);
        //Fragment duoc tao tu 1 activity nao do
        //Tra ve activity noi ma Fragment duoc tao.
        mainActivity = (MainActivity) getActivity();
        //Ánh xạ view
        initUI();
        setChangeStateOfCheckBox();
//      createNotificationChannel();
        return DetailView;

    }

    @SuppressLint("SetTextI18n")
    private void initUI() {
        ivImg = DetailView.findViewById(R.id.ivImg);
        tvNamePet = DetailView.findViewById(R.id.tvNamePet);

        cbClaw = DetailView.findViewById(R.id.cbClaw);
        cbFood = DetailView.findViewById(R.id.cbFood);
        cbHealth = DetailView.findViewById(R.id.cbHealth);
        cbShower = DetailView.findViewById(R.id.cbShower);
        cbSkin = DetailView.findViewById(R.id.cbSkin);

        tvCheckClaw = DetailView.findViewById(R.id.tvCheckClaw);
        tvCheckFood = DetailView.findViewById(R.id.tvCheckFood);
        tvCheckHealth = DetailView.findViewById(R.id.tvCheckHealth);
        tvCheckShower = DetailView.findViewById(R.id.tvCheckShower);
        tvCheckSkin = DetailView.findViewById(R.id.tvCheckSkin);

        //Lay du lieu tu object games ma truyen tu GamesActivity sang gan len cac thuoc tinh Fragment.
        petnuoi = (PetNuoi) getArguments().get("object_petnuoi");

        tvNamePet.setText(petnuoi.getNamePet());
        cbClaw.setChecked(petnuoi.isStateClaw());
        cbSkin.setChecked(petnuoi.isStateSkin());
        cbShower.setChecked(petnuoi.isStateShower());
        cbHealth.setChecked(petnuoi.isStateHealth());
        cbFood.setChecked(petnuoi.isStateFood());

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("PetNuoi");
        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                if(snapshot.getKey().equals(petnuoi.getIdPet())){
                    PetNuoi petNuoi = snapshot.getValue(PetNuoi.class);
                    if(petNuoi!=null){
                        cbClaw.setChecked(petNuoi.isStateClaw());
                        cbSkin.setChecked(petNuoi.isStateSkin());
                        cbShower.setChecked(petNuoi.isStateShower());
                        cbHealth.setChecked(petNuoi.isStateHealth());
                        cbFood.setChecked(petNuoi.isStateFood());
                    }
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        if(!cbClaw.isChecked()){
            cbClaw.setEnabled(true);
            tvCheckClaw.setVisibility(View.GONE);
        }
        if(cbClaw.isChecked()){
            cbClaw.setEnabled(false);
            tvCheckClaw.setVisibility(View.VISIBLE);
            tvCheckClaw.setText(petnuoi.getCheckStateClaw());
        }

        if(!cbFood.isChecked()){
            cbFood.setEnabled(true);
            tvCheckFood.setVisibility(View.GONE);
        }
        if(cbFood.isChecked()){
            cbFood.setEnabled(false);
            tvCheckFood.setVisibility(View.VISIBLE);
            tvCheckFood.setText(petnuoi.getCheckStateFood());
        }

        if(!cbShower.isChecked()){
            cbShower.setEnabled(true);
            tvCheckShower.setVisibility(View.GONE);
        }
        if(cbShower.isChecked()){
            cbShower.setEnabled(false);
            tvCheckShower.setVisibility(View.VISIBLE);
            tvCheckShower.setText(petnuoi.getCheckStateShower());
        }

        if(!cbHealth.isChecked()){
            cbHealth.setEnabled(true);
            tvCheckHealth.setVisibility(View.GONE);
        }
        if(cbHealth.isChecked()){
            cbHealth.setEnabled(false);
            tvCheckHealth.setVisibility(View.VISIBLE);
            tvCheckHealth.setText(petnuoi.getCheckStateHealth());
        }

        if(!cbSkin.isChecked()){
            cbSkin.setEnabled(true);
            tvCheckSkin.setVisibility(View.GONE);
        }
        if(cbSkin.isChecked()){
            cbSkin.setEnabled(false);
            tvCheckSkin.setVisibility(View.VISIBLE);
            tvCheckSkin.setText(petnuoi.getCheckStateSkin());
        }

        Glide.with(mainActivity).load(petnuoi.getUrlImageIcon()).into(ivImg);

    }

    private void setChangeStateOfCheckBox(){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("PetNuoi");

        cbClaw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                myRef.child(petnuoi.getIdPet()).child("stateClaw").setValue(isChecked);
                if(isChecked){
                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
                    currentDateAndTime = sdf.format(new Date());
                    myRef.child(petnuoi.getIdPet()).child("checkStateClaw").setValue(currentDateAndTime);
                    showDateTimeDialog("checkDateTimeStateClaw");

                    tvCheckClaw.setText(String.valueOf(currentDateAndTime));
                    tvCheckClaw.setVisibility(View.VISIBLE);
                    cbClaw.setEnabled(false);

                }
                else {
                    cbClaw.setEnabled(true);
                    tvCheckClaw.setVisibility(View.GONE);
                }
            }
        });

        cbSkin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                myRef.child(petnuoi.getIdPet()).child("stateSkin").setValue(isChecked);
                if(isChecked){
                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
                    currentDateAndTime = sdf.format(new Date());
                    myRef.child(petnuoi.getIdPet()).child("checkStateSkin").setValue(currentDateAndTime);
                    showDateTimeDialog("checkDateTimeStateSkin");
                    tvCheckSkin.setText(String.valueOf(currentDateAndTime));
                    tvCheckSkin.setVisibility(View.VISIBLE);
                    cbSkin.setEnabled(false);

                }
                else{
                    cbSkin.setEnabled(true);
                    tvCheckSkin.setVisibility(View.GONE);
                }
            }
        });

        cbShower.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                myRef.child(petnuoi.getIdPet()).child("stateShower").setValue(isChecked);
                if(isChecked){
                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
                    currentDateAndTime = sdf.format(new Date());
                    myRef.child(petnuoi.getIdPet()).child("checkStateShower").setValue(currentDateAndTime);
                    showDateTimeDialog("checkDateTimeStateShower");
                    tvCheckShower.setText(String.valueOf(currentDateAndTime));
                    tvCheckShower.setVisibility(View.VISIBLE);
                    cbShower.setEnabled(false);
                }

                else{
                    cbShower.setEnabled(true);
                    tvCheckShower.setVisibility(View.GONE);
                }
            }
        });

        cbHealth.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                myRef.child(petnuoi.getIdPet()).child("stateHealth").setValue(isChecked);
                if(isChecked){
                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
                    currentDateAndTime = sdf.format(new Date());
                    myRef.child(petnuoi.getIdPet()).child("checkStateHealth").setValue(currentDateAndTime);
                    showDateTimeDialog("checkDateTimeStateHealth");
                    tvCheckHealth.setText(String.valueOf(currentDateAndTime));
                    tvCheckHealth.setVisibility(View.VISIBLE);
                    cbHealth.setEnabled(false);
                }
                else {
                    cbHealth.setEnabled(true);
                    tvCheckHealth.setVisibility(View.GONE);
                }
            }
        });

        cbFood.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                myRef.child(petnuoi.getIdPet()).child("stateFood").setValue(isChecked);
                if(isChecked){
                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
                    currentDateAndTime = sdf.format(new Date());
                    myRef.child(petnuoi.getIdPet()).child("checkStateFood").setValue(currentDateAndTime);
                    showDateTimeDialog("checkDateTimeStateFood");
                    tvCheckFood.setText(String.valueOf(currentDateAndTime));
                    tvCheckFood.setVisibility(View.VISIBLE);
                    cbFood.setEnabled(false);
                }
                else{
                    cbFood.setEnabled(true);
                    tvCheckFood.setVisibility(View.GONE);
                }
            }
        });
    }

    private void showDateTimeDialog(String stateDateTimeCheck){
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);

                TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                        calendar.set(Calendar.MINUTE,minute);
                        calendar.set(Calendar.SECOND,0);

                        Long checkCurrent = Long.parseLong(String.valueOf(calendar.getTimeInMillis()-Calendar.getInstance().getTimeInMillis()));
                        if(checkCurrent<0){
                            Toast.makeText(mainActivity, "Ngày Giờ Chọn Không Hợp Lệ !!!", Toast.LENGTH_SHORT).show();
                            if(stateDateTimeCheck.equals("checkDateTimeStateClaw")){
                                cbClaw.setChecked(false);
                                cbClaw.setEnabled(true);
                            }

                            if(stateDateTimeCheck.equals("checkDateTimeStateFood")){
                                cbFood.setChecked(false);
                                cbFood.setEnabled(true);
                            }

                            if(stateDateTimeCheck.equals("checkDateTimeStateHealth")){
                                cbHealth.setChecked(false);
                                cbHealth.setEnabled(true);
                            }

                            if(stateDateTimeCheck.equals("checkDateTimeStateShower")){
                                cbShower.setChecked(false);
                                cbShower.setEnabled(true);
                            }

                            if(stateDateTimeCheck.equals("checkDateTimeStateSkin")){
                                cbSkin.setChecked(false);
                                cbSkin.setEnabled(true);
                            }
                        }
                        else{
                            @SuppressLint("SimpleDateFormat") SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                            FirebaseDatabase database = FirebaseDatabase.getInstance();
                            DatabaseReference myRef = database.getReference("PetNuoi");
                            myRef.child(petnuoi.getIdPet()).child(stateDateTimeCheck).setValue(simpleDateFormat.format(calendar.getTime()));

                            createNotificationChannel(stateDateTimeCheck);
                            Long current = calendar.getTimeInMillis();

                            if(stateDateTimeCheck.equals("checkDateTimeStateClaw")){
                                startAlarmClaw(current);

                            }

                            if(stateDateTimeCheck.equals("checkDateTimeStateFood")){
                                startAlarmFood(current);
                            }

                            if(stateDateTimeCheck.equals("checkDateTimeStateHealth")){
                                startAlarmHealth(current);
                            }

                            if(stateDateTimeCheck.equals("checkDateTimeStateShower")){
                                startAlarmShower(current);
                            }

                            if(stateDateTimeCheck.equals("checkDateTimeStateSkin")){
                                startAlarmSkin(current);
                            }
                        }

                    }
                };


                TimePickerDialog timePickerDialog = new TimePickerDialog(mainActivity,timeSetListener,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true);
                timePickerDialog.show();
                timePickerDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        if(stateDateTimeCheck.equals("checkDateTimeStateClaw")){
                            cbClaw.setChecked(false);
                            cbClaw.setEnabled(true);
                        }

                        if(stateDateTimeCheck.equals("checkDateTimeStateFood")){
                            cbFood.setChecked(false);
                            cbFood.setEnabled(true);
                        }

                        if(stateDateTimeCheck.equals("checkDateTimeStateHealth")){
                            cbHealth.setChecked(false);
                            cbHealth.setEnabled(true);
                        }

                        if(stateDateTimeCheck.equals("checkDateTimeStateShower")){
                            cbShower.setChecked(false);
                            cbShower.setEnabled(true);
                        }

                        if(stateDateTimeCheck.equals("checkDateTimeStateSkin")){
                            cbSkin.setChecked(false);
                            cbSkin.setEnabled(true);
                        }
                        dialog.dismiss();
                    }
                });
            }
        };

        DatePickerDialog datePickerDialog = new DatePickerDialog(mainActivity,dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
        datePickerDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                if(stateDateTimeCheck.equals("checkDateTimeStateClaw")){
                    cbClaw.setChecked(false);
                    cbClaw.setEnabled(true);
                }

                if(stateDateTimeCheck.equals("checkDateTimeStateFood")){
                    cbFood.setChecked(false);
                    cbFood.setEnabled(true);
                }

                if(stateDateTimeCheck.equals("checkDateTimeStateHealth")){
                    cbHealth.setChecked(false);
                    cbHealth.setEnabled(true);
                }

                if(stateDateTimeCheck.equals("checkDateTimeStateShower")){
                    cbShower.setChecked(false);
                    cbShower.setEnabled(true);
                }

                if(stateDateTimeCheck.equals("checkDateTimeStateSkin")){
                    cbSkin.setChecked(false);
                    cbSkin.setEnabled(true);
                }
                dialog.dismiss();
            }
        });

//        datePickerDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
//            @Override
//            public void onDismiss(DialogInterface dialog) {
//                if(stateDateTimeCheck.equals("checkDateTimeStateClaw")){
//                    cbClaw.setChecked(false);
//                    cbClaw.setEnabled(true);
//                }
//
//                if(stateDateTimeCheck.equals("checkDateTimeStateFood")){
//                    cbFood.setChecked(false);
//                    cbFood.setEnabled(true);
//                }
//
//                if(stateDateTimeCheck.equals("checkDateTimeStateHealth")){
//                    cbHealth.setChecked(false);
//                    cbHealth.setEnabled(true);
//                }
//
//                if(stateDateTimeCheck.equals("checkDateTimeStateShower")){
//                    cbShower.setChecked(false);
//                    cbShower.setEnabled(true);
//                }
//
//                if(stateDateTimeCheck.equals("checkDateTimeStateSkin")){
//                    cbSkin.setChecked(false);
//                    cbSkin.setEnabled(true);
//                }
//            }
//        });
    }



    private void startAlarmClaw(Long current){

        if(ReminderClaw.CodeSend == 199){
            codeClaw = 100;
            ReminderClaw.CodeSend = codeClaw;

        }

        if(ReminderClaw.CodeSend == 0){
            codeClaw = 100;
            ReminderClaw.CodeSend = codeClaw;

        }
        else{
            ReminderClaw.CodeSend = ReminderClaw.CodeSend + 1;
            codeClaw = ReminderClaw.CodeSend;
        }

        Intent intent = new Intent(getActivity(),ReminderClaw.class);
        intent.putExtra("namePet", petnuoi.getNamePet());
        intent.putExtra("idCn",codeClaw);
        intent.putExtra("stateClawID", petnuoi.getIdPet());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getActivity(),codeClaw, intent, PendingIntent.FLAG_MUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, current,pendingIntent);

    }




    private void startAlarmFood(Long current){
        if(ReminderFood.CodeSend == 299){
            codeFood = 200;
            ReminderFood.CodeSend = codeFood;

        }

        if(ReminderFood.CodeSend == 0){
            codeFood = 200;
            ReminderFood.CodeSend = codeFood;

        }
        else{
            ReminderFood.CodeSend = ReminderFood.CodeSend + 1;
            codeFood = ReminderFood.CodeSend;
        }

        Intent intent = new Intent(getActivity(),ReminderFood.class);
        intent.putExtra("namePet", petnuoi.getNamePet());
        intent.putExtra("idCn",codeFood);
        intent.putExtra("stateFoodID", petnuoi.getIdPet());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getActivity(),codeFood, intent, PendingIntent.FLAG_MUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, current,pendingIntent);
    }




    private void startAlarmHealth(Long current){
        if(ReminderHealth.CodeSend == 399){
            codeHealth = 300;
            ReminderHealth.CodeSend = codeHealth;

        }

        if(ReminderHealth.CodeSend == 0){
            codeHealth = 300;
            ReminderHealth.CodeSend = codeHealth;

        }
        else{
            ReminderHealth.CodeSend = ReminderHealth.CodeSend + 1;
            codeHealth = ReminderHealth.CodeSend;
        }

        Intent intent = new Intent(getActivity(),ReminderHealth.class);
        intent.putExtra("namePet", petnuoi.getNamePet());
        intent.putExtra("idCn",codeHealth);
        intent.putExtra("stateHealthID", petnuoi.getIdPet());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getActivity(),codeHealth, intent, PendingIntent.FLAG_MUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, current,pendingIntent);
    }


    private void startAlarmShower(Long current){
        if(ReminderShower.CodeSend == 499){
            codeShower = 400;
            ReminderShower.CodeSend = codeShower;

        }

        if(ReminderShower.CodeSend == 0){
            codeShower = 400;
            ReminderShower.CodeSend = codeShower;

        }
        else{
            ReminderShower.CodeSend = ReminderShower.CodeSend + 1;
            codeShower = ReminderShower.CodeSend;
        }

        Intent intent = new Intent(getActivity(),ReminderShower.class);
        intent.putExtra("namePet", petnuoi.getNamePet());
        intent.putExtra("idCn",codeShower);
        intent.putExtra("stateShowerID", petnuoi.getIdPet());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getActivity(),codeShower, intent, PendingIntent.FLAG_MUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, current,pendingIntent);
    }



    private void startAlarmSkin(Long current){
        if(ReminderSkin.CodeSend == 599){
            codeSkin = 500;
            ReminderSkin.CodeSend = codeSkin;

        }

        if(ReminderSkin.CodeSend == 0){
            codeSkin = 500;
            ReminderSkin.CodeSend = codeSkin;

        }
        else{
            ReminderSkin.CodeSend = ReminderSkin.CodeSend + 1;
            codeSkin = ReminderSkin.CodeSend;
        }

        Intent intent = new Intent(getActivity(),ReminderSkin.class);
        intent.putExtra("namePet", petnuoi.getNamePet());
        intent.putExtra("idCn",codeSkin);
        intent.putExtra("stateSkinID", petnuoi.getIdPet());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getActivity(),codeSkin, intent, PendingIntent.FLAG_MUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, current,pendingIntent);
    }





    private void createNotificationChannel(String idChannel){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name = "PetApp Reminder";
            String des = "Channel for PetApp Reminder";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(idChannel, name, importance);
            channel.setDescription(des);

            NotificationManager notificationManager = getActivity().getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

//    private void startAlarm(){
//        AlarmManager alarmManager = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);
//        Intent intent = new Intent(getActivity(), ReminderBroadcast.class);
//
//        PendingIntent pendingIntent = PendingIntent.getBroadcast(getActivity(), 1, intent, PendingIntent.FLAG_MUTABLE);
//        alarmManager.setExact(AlarmManager.RTC_WAKEUP, 1000, pendingIntent);
//    }




//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
//                                           @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        switch (requestCode) {
//            case REQUEST_POST_NOTIFICATIONS_PERMISSION:
//                for (int grantResult : grantResults) {
//                    if (grantResult != PackageManager.PERMISSION_GRANTED) {
//
//                    }
//                }
//                break;
//        }
//    }

}