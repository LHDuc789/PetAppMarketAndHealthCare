package com.example.khachhang.CarePackage;

import java.io.Serializable;

public class PetNuoi implements Serializable {
    private String IdPet;
    private String IdUser;
    private String NamePet;
    private String NameOfType;

    //State
    private boolean StateFood;
    private boolean StateShower;
    private boolean StateHealth;
    private boolean StateSkin;
    private boolean StateClaw;

    //Date State
    private String CheckStateClaw;
    private String CheckStateFood;
    private String CheckStateSkin;
    private String CheckStateHealth;
    private String CheckStateShower;
    private String UrlImageIcon;

    private int TotalLike;

    public PetNuoi(){

    }

    public PetNuoi(String idPet, String idUser, String namePet, String nameOfType, boolean stateFood, boolean stateShower, boolean stateHealth, boolean stateSkin, boolean stateClaw, String urlImageIcon, int totalLike) {
        IdPet = idPet;
        IdUser = idUser;
        NamePet = namePet;
        NameOfType = nameOfType;
        StateFood = stateFood;
        StateShower = stateShower;
        StateHealth = stateHealth;
        StateSkin = stateSkin;
        StateClaw = stateClaw;
        UrlImageIcon = urlImageIcon;
        TotalLike = totalLike;

    }



    public String getIdPet() {
        return IdPet;
    }

    public void setIdPet(String idPet) {
        IdPet = idPet;
    }

    public String getIdUser() {
        return IdUser;
    }

    public void setIdUser(String idUser) {
        IdUser = idUser;
    }

    public String getNamePet() {
        return NamePet;
    }

    public void setNamePet(String namePet) {
        NamePet = namePet;
    }

    public String getNameOfType() {
        return NameOfType;
    }

    public void setNameOfType(String nameOfType) {
        NameOfType = nameOfType;
    }

    public boolean isStateFood() {
        return StateFood;
    }

    public void setStateFood(boolean stateFood) {
        StateFood = stateFood;
    }

    public boolean isStateShower() {
        return StateShower;
    }

    public void setStateShower(boolean stateShower) {
        StateShower = stateShower;
    }

    public boolean isStateHealth() {
        return StateHealth;
    }

    public void setStateHealth(boolean stateHealth) {
        StateHealth = stateHealth;
    }

    public boolean isStateSkin() {
        return StateSkin;
    }

    public void setStateSkin(boolean stateSkin) {
        StateSkin = stateSkin;
    }

    public boolean isStateClaw() {
        return StateClaw;
    }

    public void setStateClaw(boolean stateClaw) {
        StateClaw = stateClaw;
    }

    public String getUrlImageIcon() {
        return UrlImageIcon;
    }

    public void setUrlImageIcon(String urlImageIcon) {
        UrlImageIcon = urlImageIcon;
    }

    public String getCheckStateClaw() {
        return CheckStateClaw;
    }

    public void setCheckStateClaw(String checkStateClaw) {
        CheckStateClaw = checkStateClaw;
    }

    public String getCheckStateFood() {
        return CheckStateFood;
    }

    public void setCheckStateFood(String checkStateFood) {
        CheckStateFood = checkStateFood;
    }

    public String getCheckStateSkin() {
        return CheckStateSkin;
    }

    public void setCheckStateSkin(String checkStateSkin) {
        CheckStateSkin = checkStateSkin;
    }

    public String getCheckStateHealth() {
        return CheckStateHealth;
    }

    public void setCheckStateHealth(String checkStateHealth) {
        CheckStateHealth = checkStateHealth;
    }

    public String getCheckStateShower() {
        return CheckStateShower;
    }

    public void setCheckStateShower(String checkStateShower) {
        CheckStateShower = checkStateShower;
    }

    public int getTotalLike() {
        return TotalLike;
    }

    public void setTotalLike(int totalLike) {
        TotalLike = totalLike;
    }
}
