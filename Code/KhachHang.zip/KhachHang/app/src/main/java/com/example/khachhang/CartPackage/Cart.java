package com.example.khachhang.CartPackage;

import java.io.Serializable;

public class Cart implements Serializable {
    private String IdPetBan;
    private String IdUser;
    private int Number;
    private String IdCart;

    public Cart(String IdPetBan, String IdUser, int Number, String IdCart){
        this.IdPetBan = IdPetBan;
        this.IdUser = IdUser;
        this.Number = Number;
        this.IdCart = IdCart;
    }

    public Cart(){
    }

    public String getIdCart() {
        return IdCart;
    }

    public void setIdCart(String idCart) {
        IdCart = idCart;
    }

    public String getIdPetBan() {
        return IdPetBan;
    }

    public void setIdPetBan(String idPetBan) {
        IdPetBan = idPetBan;
    }

    public String getIdUser() {
        return IdUser;
    }

    public void setIdUser(String idUser) {
        IdUser = idUser;
    }

    public int getNumber() {
        return Number;
    }

    public void setNumber(int number) {
        Number = number;
    }
}
