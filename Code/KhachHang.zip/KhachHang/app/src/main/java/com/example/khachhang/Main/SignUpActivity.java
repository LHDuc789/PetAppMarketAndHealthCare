package com.example.khachhang.Main;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.khachhang.R;
import com.example.khachhang.UserPackage.Customer;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SignUpActivity extends AppCompatActivity {

    private EditText SignUpFullName,SignUpEmail,SignUpPassword,SignUpConfirmPassword;
    private Button btnSignUp;
    int lastsize;

//    private Button btnCancel;

    private ProgressDialog progressDialog;
    private String idUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        getCustomerListFromRealtimeDataBase();

        initUi();
        initListener();
    }

    private void initUi() {
        SignUpFullName = findViewById(R.id.SignUpFullName);
        SignUpEmail = findViewById(R.id.SignUpEmail);
        SignUpPassword = findViewById(R.id.SignUpPassword);
        SignUpConfirmPassword = findViewById(R.id.SignUpConfirmPassword);
        btnSignUp = findViewById(R.id.btnSignUp);
//        btnCancel = findViewById(R.id.btnCancel);


        progressDialog = new ProgressDialog(this);
    }

    private void initListener() {
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickSignUp();
            }
        });

//        btnCancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////               Intent intent = new Intent(AddCustomerActivity.this,MainActivity.class);
////               startActivity(intent);
//                onBackPressed();
//            }
//        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }


    public void getCustomerListFromRealtimeDataBase() {
        //Goi toi Firebase voi key parent la Games.
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_re = database.getReference("User");

        //Lay ra phan tu cuoi cung
        myRef_re.orderByChild("createDate").limitToLast(1).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Customer d = snapshot.getValue(Customer.class);
                if (d != null) {
                    if (!d.getIdUser().equals("Admin")) {
                        //Chi lay phan so cua IdUser
                        String[] part = d.getIdUser().split("(?<=\\D)(?=\\d)");
                        lastsize = Integer.parseInt(part[1]);
                    } else {
                        lastsize = 1;
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });
    }

    private void onClickSignUp() {

        String fullname = SignUpFullName.getText().toString().trim();
        String email = SignUpEmail.getText().toString().trim();
        String password = SignUpPassword.getText().toString().trim();
        String confirmpassword = SignUpConfirmPassword.getText().toString().trim();

        if(TextUtils.isEmpty(fullname)){
            Toast.makeText(SignUpActivity.this, "Vui Lòng Nhập Họ Tên Của Bạn.",
                    Toast.LENGTH_SHORT).show();
        }

        else if(TextUtils.isEmpty(email)){
            Toast.makeText(SignUpActivity.this, "Vui Lòng Nhập Địa Chỉ Email.",
                    Toast.LENGTH_SHORT).show();
        }

        else if(TextUtils.isEmpty(password)){
            Toast.makeText(SignUpActivity.this, "Vui Lòng Nhập Mật Khẩu.",
                    Toast.LENGTH_SHORT).show();
        }

        else if(TextUtils.isEmpty(confirmpassword)){
            Toast.makeText(SignUpActivity.this, "Vui Lòng Xác Nhận Lại Mật Khẩu.",
                    Toast.LENGTH_SHORT).show();
        }

        else if(!password.equals(confirmpassword)){
            Toast.makeText(SignUpActivity.this, "Hai Mật Khẩu Không Khớp Nhau.",
                    Toast.LENGTH_SHORT).show();
        }

        else {
            //Dua du lieu vao class Games.
            Customer new_customer = new Customer(fullname,email);
//            if ((nextId)<10){
//                new_customer.setIdUser("KH0"+String.valueOf(nextId));
//            }
//            else{
//                new_customer.setIdUser("KH"+String.valueOf(nextId));
//            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
            String currentDateAndTime = sdf.format(new Date());
            new_customer.setPhone("");

            StorageReference reference = FirebaseStorage.getInstance().getReference().child("default");
            StorageReference fileRef = reference.child("ic_defaultavatar.png");

            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                new_customer.setUrlImageIcon(String.valueOf(uri1));
            });

            new_customer.setAddress("");
            new_customer.setCreateDate(currentDateAndTime);

            //Create a password-based account
            FirebaseAuth auth = FirebaseAuth.getInstance();
            progressDialog.setMessage("Đang Tạo Mới Tài Khoản.");
            progressDialog.show();
            auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            progressDialog.dismiss();
                            if (task.isSuccessful()) {
                                FirebaseUser user = task.getResult().getUser();

                                if((lastsize+1) < 10){
                                    idUser = "KH0" + (lastsize+1);
                                }
                                else{
                                    idUser = "KH" + (lastsize+1);
                                }

                                new_customer.setIdUser(idUser);

                                DatabaseReference root = FirebaseDatabase.getInstance().getReference("User");
                                root.child(user.getUid()).setValue(new_customer);

                                Toast.makeText(SignUpActivity.this, "Thêm Mới Tài Khoản Thành Công",
                                        Toast.LENGTH_SHORT).show();

                                // Sign in success, update UI with the signed-in user's information
                                Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
                                startActivity(intent);
                                finishAffinity();
                            } else {

                                try
                                {
                                    throw task.getException();
                                }
                                // if user enters wrong email.
                                catch (FirebaseAuthWeakPasswordException weakPassword)
                                {

                                    Toast.makeText(SignUpActivity.this, "Mật Khẩu Không Đáp Ứng Đủ Điều Kiện Bảo Mật.",
                                            Toast.LENGTH_SHORT).show();
                                }
                                catch (FirebaseAuthInvalidCredentialsException malformedEmail)
                                {
                                    Toast.makeText(SignUpActivity.this, "Email Không Họp Lệ.",
                                            Toast.LENGTH_SHORT).show();
                                }
                                catch (FirebaseAuthUserCollisionException existEmail)
                                {
                                    Toast.makeText(SignUpActivity.this, "Email Này Đã Được Sử Dụng.",
                                            Toast.LENGTH_SHORT).show();
                                }
                                catch (Exception e)
                                {
                                    Toast.makeText(SignUpActivity.this, "Thêm Mới Tài Khoản Thất Bại",
                                            Toast.LENGTH_SHORT).show();
                                }

                            }
                        }
                    });
        }


    }


}