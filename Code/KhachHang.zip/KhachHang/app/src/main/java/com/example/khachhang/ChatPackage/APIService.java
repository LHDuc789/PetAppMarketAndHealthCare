package com.example.khachhang.ChatPackage;

import com.example.khachhang.Notifications.MyResponse;
import com.example.khachhang.Notifications.Sender;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {
    @Headers(
            {
                    "Content-Type:application/json",
                    "Authorization:key=AAAAp1uXaAU:APA91bHj1Dcp11W_BJG-p4sUO_hrgoQLxVujHHWAoshxbeDTKYooNS8Pd3SOB-lnChFZzFgOB6J3CuUshBttQ5zoARGRecB4tnnhn4WCHyTuXq4LU4dfFNNGMR_2JQC1ETW3O85xg7NG"
            }
    )
    @POST("fcm/send")
    Call<MyResponse> sendNotification(@Body Sender body);
}
