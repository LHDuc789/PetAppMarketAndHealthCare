package com.example.khachhang.CartPackage;

import static android.view.View.GONE;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.khachhang.Interface.ClickItemPetBan;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.R;
import com.example.khachhang.ShopPackage.DetailPetBanFragment;
import com.example.khachhang.ShopPackage.DetailProfit;
import com.example.khachhang.ShopPackage.PetBan;
import com.example.khachhang.ShopPackage.PetBanAdapter;
import com.example.khachhang.ShopPackage.Profit;
import com.example.khachhang.ShopPackage.ShopFragment;
import com.example.khachhang.UserPackage.ADetailCustomerFragment;
import com.example.khachhang.UserPackage.Customer;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CartFragment extends Fragment {

    private View mView;
    private RecyclerView rcvCart;
    private MainActivity mainActivity;
    ArrayList<Cart> carts;
    CartAdapter cartAdapter;
    private FrameLayout rootView;
    private ProgressDialog progressDialog;
    public static final String TAG = CartFragment.class.getName();
    Customer customer;
    private TextView total;
    private int t = 0;
    int lastsizeprofit;
    String IdProfit;
    String IdDetailProfit;
    int lastsizedetailprofit;
    private Button btnConfirmBuy;
    int confirm = 0;



    public CartFragment() {
        // Required empty public constructor
    }

    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static CartFragment getInstance(Customer customer){
        CartFragment cartFragment = new CartFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_customer",customer);
        cartFragment.setArguments(bundle);
        return cartFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_cart, container, false);

        initUi();
        getCartListFromRealtimeDataBase();

        return mView;
    }

    public void initUi(){
        //Khoi tao gamesActivity de su dung.
        mainActivity = (MainActivity) getActivity();
        progressDialog = new ProgressDialog(mainActivity);

//        rootView = mView.findViewById(R.id.apps_root_view);
        rcvCart = mView.findViewById(R.id.CartList);

        TextView nameUser = mView.findViewById(R.id.nameUser);
        total = mView.findViewById(R.id.tvTotal);

        btnConfirmBuy = mView.findViewById(R.id.btnConfirmBuy);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mainActivity);
        rcvCart.setLayoutManager(linearLayoutManager);

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mainActivity,DividerItemDecoration.VERTICAL);
        rcvCart.addItemDecoration(itemDecoration);

        carts = new ArrayList<>();

        cartAdapter = new CartAdapter(mainActivity, carts, new ClickItemPetBan() {
            @Override
            public void onClickItemPetBan(PetBan petBan) {
                mainActivity.sendDataToDetailPetBanFragment(petBan);
            }

            @Override
            public void onClickDeleteCart(Cart cart) {
                deleteCart(cart);
            }

            @Override
            public void onClickEditPetBan(PetBan petBan) {
//                mainActivity.sendDataToEditPetBanFragment(petBan);
            }
        });

        rcvCart.setAdapter(cartAdapter);

        //Gan Option Menu len Fragment.
        setHasOptionsMenu(true);

        customer = (Customer) getArguments().get("object_customer");
        nameUser.setText(customer.getName());

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_reprofit = database.getReference("Bill");
        myRef_reprofit.orderByKey().limitToLast(1).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Profit profit = snapshot.getValue(Profit.class);
                if (profit != null) {
                    //Chi lay phan so cua IdPet
                    String[] part = profit.getIdBill().split("(?<=\\D)(?=\\d)");
                    lastsizeprofit = Integer.parseInt(part[1]);
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        DatabaseReference myRef_redesprofit = database.getReference("DesBill");
        myRef_redesprofit.orderByKey().limitToLast(1).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                DetailProfit detailProfit = snapshot.getValue(DetailProfit.class);
                if (detailProfit != null) {
                    //Chi lay phan so cua IdPet
                    String[] part = detailProfit.getIdDesBill().split("(?<=\\D)(?=\\d)");
                    lastsizedetailprofit = Integer.parseInt(part[1]);
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btnConfirmBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmCart();
            }
        });

    }

    public void getCartListFromRealtimeDataBase() {
        //Goi toi Firebase voi key parent la Games.
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Cart");
        DatabaseReference myRef_re = database.getReference("PetBan");


        //Lay ra phan tu cuoi cung
        myRef.addChildEventListener(new ChildEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Cart d = snapshot.getValue(Cart.class);
                if (d != null) {
                    if(d.getIdUser().equals(customer.getIdUser())){

                        carts.add(d);

                        cartAdapter.notifyDataSetChanged();


                        myRef_re.addChildEventListener(new ChildEventListener() {
                            @SuppressLint("SetTextI18n")
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                                PetBan e = snapshot.getValue(PetBan.class);
                                if (e!=null && e.getIdPet().equals(d.getIdPetBan())){
                                    t = t + d.getNumber()*e.getCost();
                                }
                                total.setText("Tổng Cộng: " + t);
                            }

                            @Override
                            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                Cart cart = snapshot.getValue(Cart.class);
                if(cart == null || carts == null || carts.isEmpty()){
                    return;
                }
                for(int i = 0; i < carts.size(); i++) {
                    if (cart.getIdCart().equals(carts.get(i).getIdCart())) {
                        carts.remove(carts.get(i));
                        break;
                    }
                }
                cartAdapter.notifyDataSetChanged();
                myRef_re.addChildEventListener(new ChildEventListener() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        PetBan e = snapshot.getValue(PetBan.class);
                        if (e!=null && e.getIdPet().equals(cart.getIdPetBan())){
                            t = t - cart.getNumber()*e.getCost();
                        }
                        total.setText("Tổng Cộng: " + t);
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });
    }

    private void deleteCart(Cart cart){
        new AlertDialog.Builder(mainActivity)
                .setTitle("Xóa Khỏi Giỏ Hàng")
                .setMessage("Bạn có chắc muốn xóa Pet này khỏi giỏ hàng không ?")
                .setPositiveButton("Đồng Ý", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        progressDialog.setMessage("Đang Xóa Khỏi Giỏ Hàng");
                        progressDialog.show();
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("Cart");
                        myRef.child(cart.getIdCart()).removeValue(new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
                                //Xoa het toan bo anh trong thu muc.
                                //Doi 2 giay.
                                Handler handler = new Handler();
                                handler.postDelayed(() -> {
                                    progressDialog.dismiss();
                                    Toast.makeText(mainActivity,"Đã xóa khỏi giỏ hàng thành công",Toast.LENGTH_LONG).show();
                                },2000);
                            }
                        });
                    }
                })
                .setNegativeButton("Không", null)
                .show();
    }

    private void confirmCart(){
        confirm = 1;
         new AlertDialog.Builder(mainActivity)
                .setTitle("Xác Nhận Thanh Toán")
                .setMessage("Xác Nhận Thanh Toán Giỏ Hàng ?")
                .setPositiveButton("Đồng Ý", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        progressDialog.setMessage("Đang Thiết Lập Hóa Đơn");
                        progressDialog.show();

                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("Cart");
                        DatabaseReference myRef_re = database.getReference("PetBan");
                        DatabaseReference myRef_reprofit = database.getReference("Bill");
                        DatabaseReference myRef_redesprofit = database.getReference("DesBill");

                        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
                        String currentDateAndTime = sdf.format(new Date());
                        //Lay ra phan tu cuoi cung
                        myRef.addChildEventListener(new ChildEventListener() {
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                                Cart d = snapshot.getValue(Cart.class);
                                if (d != null) {
                                    if(d.getIdUser().equals(customer.getIdUser())){
                                        if((lastsizeprofit+1)<10){
                                            IdProfit = "B0" + (lastsizeprofit+1);
                                        }
                                        else{
                                            IdProfit = "B" + (lastsizeprofit+1);
                                        }

                                    }
                                }

                                if(confirm == 1){
                                    Profit profit = new Profit(IdProfit,customer.getIdUser(),customer.getName(),currentDateAndTime,customer.getPhone(),customer.getAddress(),customer.getEmail(),"False");
                                    myRef_reprofit.child(profit.getIdBill()).setValue(profit);

                                    myRef_re.addChildEventListener(new ChildEventListener() {
                                        @Override
                                        public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                                            PetBan e = snapshot.getValue(PetBan.class);
                                            if (e!=null && e.getIdPet().equals(d.getIdPetBan())){
                                                if((lastsizedetailprofit+1)<10){
                                                    IdDetailProfit = "DB0" + (lastsizedetailprofit+1);
                                                }
                                                else{
                                                    IdDetailProfit = "DB" + (lastsizedetailprofit+1);

                                                }
                                                lastsizedetailprofit = lastsizedetailprofit + 1;
                                                DetailProfit detailProfit = new DetailProfit(IdDetailProfit,IdProfit,e.getIdPet(),e.getUrlImageIcon(),e.getCost(),d.getNumber());
                                                myRef_redesprofit.child(IdDetailProfit).setValue(detailProfit).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void unused) {
                                                        myRef.child(d.getIdCart()).removeValue();
                                                    }
                                                });
                                            }
                                        }

                                        @Override
                                        public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                        }

                                        @Override
                                        public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                                        }

                                        @Override
                                        public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });
                                }
                            }

                            @Override
                            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }

                        });
                        Handler handler = new Handler();
                        handler.postDelayed(() -> {
                            progressDialog.dismiss();
                            confirm = 0;
                            Toast.makeText(mainActivity,"Hoàn Tất Xác Nhận",Toast.LENGTH_LONG).show();
//                            getActivity().getSupportFragmentManager().beginTransaction().remove(CartFragment.this).commitAllowingStateLoss();

//                            Intent intent = new Intent(getActivity(), MainActivity.class);
//                            startActivity(intent);
                            FragmentManager fmManager = getActivity().getSupportFragmentManager();
                            fmManager.popBackStack();
//                            fmManager.beginTransaction().replace(R.id.view_pager, new ShopFragment()).addToBackStack(null).commit();

                        },2000);
                    }
                })
                .setNegativeButton("Không", null)
                .show();

    }
}