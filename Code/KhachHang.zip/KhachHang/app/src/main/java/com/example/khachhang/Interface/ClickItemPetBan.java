package com.example.khachhang.Interface;

import com.example.khachhang.CartPackage.Cart;
import com.example.khachhang.ShopPackage.PetBan;

public interface ClickItemPetBan {
    void onClickItemPetBan(PetBan petBan);
    void onClickDeleteCart(Cart cart);
    void onClickEditPetBan(PetBan petBan);
}
