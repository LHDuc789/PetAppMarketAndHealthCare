package com.example.khachhang.ChatPackage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.khachhang.Interface.ClickItemPetNuoi;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.R;
import com.example.khachhang.UserPackage.Customer;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class PetNuoiAdapter extends RecyclerView.Adapter<PetNuoiAdapter.ViewHolder>{
    private List<PetNuoi> mPetNuoi;
    private final Context mContext;



    public PetNuoiAdapter(Context mContext,List _petbans){
        this.mContext = mContext;
        this.mPetNuoi = _petbans;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View petnuoiView = inflater.inflate(R.layout.item_pet_like,parent,false);
        return new ViewHolder(petnuoiView);
    }

    @SuppressLint({"DefaultLocale", "SetTextI18n"})
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Lay ra vi tri cua thang object Games bat ki khi duoc click
        final PetNuoi petnuoi = (PetNuoi) mPetNuoi.get(position);
        if (petnuoi == null){
            return;
        }


        holder.tvName.setText("Tên: " + petnuoi.getNamePet());
        holder.tvNameOfType.setText("Tên Loài: " + petnuoi.getNameOfType());
        holder.tvTotalLike.setText("Tổng Số Lượt Thích: " + petnuoi.getTotalLike());

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_re = database.getReference("User");
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();


        myRef_re.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                if(petnuoi.getIdUser().equals(snapshot.getKey())){
                    Customer customer = snapshot.getValue(Customer.class);
                    if (customer!= null){
                        holder.tvNameOfUser.setText("Tên Người Nuôi: " + customer.getName());
                    }

                    if(user.getUid().equals(snapshot.getKey())){
                        holder.btnChat.setVisibility(View.GONE);
                    }
                    else {
                        holder.btnChat.setVisibility(View.VISIBLE);
                    }
                }

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //Su dung thu vien Glide de load anh lay tu firebase ve.
        Glide.with(mContext).load(petnuoi.getUrlImageIcon()).into(holder.ivImg);
//        holder.ivImg.setImageResource(games.getImg());\


//        if(petnuoi.getIdPet().equals()) {
//            holder.cbLike.setChecked(true);
//            holder.cbLike.setBackgroundResource(R.drawable.ic_favorite);
//
//        }
//
//        if(!petnuoi.isCheckLike()) {
//            holder.cbLike.setChecked(false);
//            holder.cbLike.setBackgroundResource(R.drawable.ic_favorite_border);
//        }


        DatabaseReference myRef_reLike = database.getReference("Like").child(user.getUid());


        myRef_reLike.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                if(petnuoi.getIdPet().equals(snapshot.getKey())){
                    Boolean ck = snapshot.getValue(Boolean.class);
                    if(Boolean.TRUE.equals(ck)){
                        holder.cbLike.setChecked(true);
                        holder.cbLike.setBackgroundResource(R.drawable.ic_favorite);
                    }
                    else{
                        holder.cbLike.setChecked(false);
                        holder.cbLike.setBackgroundResource(R.drawable.ic_favorite_border);
                    }
                }


            }


            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        DatabaseReference myRef_rePetNuoi = database.getReference("PetNuoi");


        holder.cbLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(holder.cbLike.isChecked()){
                    holder.cbLike.setBackgroundResource(R.drawable.ic_favorite);
//                    petnuoi_new.setCountLike(petnuoi.getCountLike()+1);
                    myRef_reLike.child(petnuoi.getIdPet()).setValue(true);
                    myRef_rePetNuoi.addChildEventListener(new ChildEventListener() {
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                            if(snapshot.getKey().equals(petnuoi.getIdPet())){
                                com.example.khachhang.CarePackage.PetNuoi p = snapshot.getValue(com.example.khachhang.CarePackage.PetNuoi.class);
                                if(p!=null){
                                    int sumLike = p.getTotalLike() + 1;
                                    myRef_rePetNuoi.child(petnuoi.getIdPet()).child("totalLike").setValue(sumLike);
                                }
                            }
                        }

                        @Override
                        public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        }

                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
                else{
                    holder.cbLike.setBackgroundResource(R.drawable.ic_favorite_border);
//                    petnuoi_new.setCountLike(petnuoi.getCountLike()-1);
                    myRef_reLike.child(petnuoi.getIdPet()).setValue(false);
                    myRef_rePetNuoi.addChildEventListener(new ChildEventListener() {
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                            if(snapshot.getKey().equals(petnuoi.getIdPet())){
                                com.example.khachhang.CarePackage.PetNuoi p = snapshot.getValue(com.example.khachhang.CarePackage.PetNuoi.class);
                                if(p!=null){
                                    int sumLike = p.getTotalLike() - 1;
                                    myRef_rePetNuoi.child(petnuoi.getIdPet()).child("totalLike").setValue(sumLike);
                                }
                            }
                        }

                        @Override
                        public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                        }

                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        });

        holder.btnChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myRef_re.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        if(petnuoi.getIdUser().equals(snapshot.getKey()) && !snapshot.getKey().equals(user.getUid())){
                            MainActivity.check = 1;
                            Intent intent = new Intent(mContext, MessageActivity.class);
                            intent.putExtra("idUser",snapshot.getKey());
                            mContext.startActivity(intent);
                        }
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return mPetNuoi.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvName;
        public TextView tvNameOfUser;
        public TextView tvNameOfType;
        public ImageView ivImg;
        public LinearLayout PetNuoiListItem;
        public CheckBox cbLike;
        public TextView tvTotalLike;
        public ImageView btnChat;

        public ViewHolder(View itemView) {
            super(itemView);
            ivImg = itemView.findViewById(R.id.ivImg);
            tvName = itemView.findViewById(R.id.tvName);
            tvNameOfType = itemView.findViewById(R.id.tvNameOfType);
            PetNuoiListItem = itemView.findViewById(R.id.PetNuoiListItem);
            cbLike = itemView.findViewById(R.id.cbLike);
            tvNameOfUser = itemView.findViewById(R.id.tvNameOfUser);
            tvTotalLike = itemView.findViewById(R.id.tvTotalLike);
            btnChat = itemView.findViewById(R.id.btnChat);
        }
    }
}
