package com.example.khachhang.Main;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.khachhang.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

public class ForgetPasswordActivity extends AppCompatActivity {


    private EditText etEmail;
    private Button btnEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        initUI();
        initListener();
    }



    public void initUI() {
        etEmail = findViewById(R.id.etEmail);
        btnEmail = findViewById(R.id.btnEmail);
    }

    public void initListener() {
        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                if(TextUtils.isEmpty(email)){
                    Toast.makeText(ForgetPasswordActivity.this, "Vui Lòng Nhập Địa Chỉ Email.",
                            Toast.LENGTH_SHORT).show();
                }
                else{
                    FirebaseAuth auth = FirebaseAuth.getInstance();
                    String emailAddress = email;

                    auth.sendPasswordResetEmail(emailAddress)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(ForgetPasswordActivity.this, "Vui lòng kiểm tra email của bạn.", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(ForgetPasswordActivity.this, SignInActivity.class);
                                        startActivity(intent);
                                    }
                                    else {
                                        try {
                                            throw task.getException();
                                        }
                                        // if user enters wrong email.
                                        catch (FirebaseAuthInvalidUserException invalidEmail) {
                                            Toast.makeText(ForgetPasswordActivity.this, "Email Này Không Tồn Tại.",
                                                    Toast.LENGTH_SHORT).show();
                                        }

                                        catch (FirebaseAuthInvalidCredentialsException malformedEmail)
                                        {
                                            Toast.makeText(ForgetPasswordActivity.this, "Email Không Họp Lệ.",
                                                    Toast.LENGTH_SHORT).show();
                                        }

                                        catch (Exception e) {
                                            Toast.makeText(ForgetPasswordActivity.this, "Không Thể Gửi Email Khôi Phục Mật Khẩu.",
                                                    Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }
                            });
                }
            }
        });
    }


}