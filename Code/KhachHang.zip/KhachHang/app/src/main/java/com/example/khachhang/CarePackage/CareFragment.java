package com.example.khachhang.CarePackage;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.example.khachhang.Interface.ClickItemPetNuoi;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;


public class CareFragment extends Fragment {

    private View mView;
    private RecyclerView rcvPetNuoi;
    private MainActivity mainActivity;
    ArrayList<PetNuoi> petnuois;
    int lastsize;
    PetNuoiAdapter petNuoiAdapter;
    private FrameLayout rootView;
    private ProgressDialog progressDialog;
    private Button btnAddPetNuoi;


    public CareFragment() {
        // Required empty public constructor
    }


//    public static PetFragment newInstance() {
//        PetFragment fragment = new PetFragment();
//        return fragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//
//        }
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_care, container, false);
        initUi();
        initListener();
        getPetNuoiListFromRealtimeDataBase();
        return mView;
    }

    public void initUi(){
        //Khoi tao gamesActivity de su dung.
        mainActivity = (MainActivity) getActivity();
        progressDialog = new ProgressDialog(mainActivity);
        btnAddPetNuoi = mView.findViewById(R.id.btnAddPetNuoi);
//        rootView = mView.findViewById(R.id.apps_root_view);
        rcvPetNuoi = mView.findViewById(R.id.PetNuoiList);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mainActivity);
        rcvPetNuoi.setLayoutManager(linearLayoutManager);

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mainActivity,DividerItemDecoration.VERTICAL);
        rcvPetNuoi.addItemDecoration(itemDecoration);

        petnuois = new ArrayList<>();

        petNuoiAdapter = new PetNuoiAdapter(mainActivity, petnuois, new ClickItemPetNuoi() {
            @Override
            public void onClickItemPetNuoi(PetNuoi petNuoi) {
                mainActivity.sendDataToDetailPetNuoiFragment(petNuoi);

            }

            @Override
            public void onClickDeletePetNuoi(PetNuoi petNuoi) {
                    deletePetNuoi(petNuoi);
            }

            @Override
            public void onClickEditPetNuoi(PetNuoi petNuoi) {
                mainActivity.sendDataToEditPetNuoiFragment(petNuoi);
            }
        });

        rcvPetNuoi.setAdapter(petNuoiAdapter);

        //Gan Option Menu len Fragment.
        setHasOptionsMenu(true);

    }

    public void initListener(){
        btnAddPetNuoi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.sendDataToAddPetNuoiFragment(lastsize);
            }
        });
    }

    public void getPetNuoiListFromRealtimeDataBase() {

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("PetNuoi");
        DatabaseReference myRef_re = database.getReference("PetNuoi");

        //Lay ra phan tu cuoi cung
        myRef_re.orderByKey().limitToLast(1).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                PetNuoi d = snapshot.getValue(PetNuoi.class);
                if (d != null) {
                    //Chi lay phan so cua IdPet
                    String[] part = d.getIdPet().split("(?<=\\D)(?=\\d)");
                    lastsize = Integer.parseInt(part[1]);
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });


        //Add tat ca du lieu len firebase.
//        myRef.setValue(games, new DatabaseReference.CompletionListener() {
//            @Override
//            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
//                Toast.makeText(gamesActivity,"Add all games success",Toast.LENGTH_LONG).show();
//            }
//        });

//        //Sap xep du lieu theo key.
//        Query query = myRef.orderByKey();

        //Cach 1: Doc data tu firebase va dong thoi cap nhat lai adapter.
        myRef.addChildEventListener(new ChildEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                PetNuoi c = snapshot.getValue(PetNuoi.class);
                if (c != null) {
                    if(c.getIdUser().equals(user.getUid())){
                        petnuois.add(c);
                        petNuoiAdapter.notifyDataSetChanged();
                    }
                }

            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                PetNuoi petnuoi = snapshot.getValue(PetNuoi.class);
                if(petnuoi == null || petnuois == null || petnuois.isEmpty()){
                    return;
                }
                for(int i = 0; i < petnuois.size(); i++) {
                    if (petnuoi.getIdPet().equals(petnuois.get(i).getIdPet())) {
                        petnuois.set(i,petnuoi);
                        break;
                    }
                }

                petNuoiAdapter.notifyDataSetChanged();
            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                PetNuoi petnuoi = snapshot.getValue(PetNuoi.class);
                if(petnuoi == null || petnuois == null || petnuois.isEmpty()){
                    return;
                }
                for(int i = 0; i < petnuois.size(); i++) {
                    if (petnuoi.getIdPet().equals(petnuois.get(i).getIdPet())) {
                        petnuois.remove(petnuois.get(i));
                        break;
                    }
                }

                petNuoiAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



//    @SuppressLint("NonConstantResourceId")
//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        switch (item.getItemId()){
//            case R.id.btnAddPetNuoi:
//                //Khi bam add item thi se dua tong so luong item ton tai trong database sang AddFragment.
//                mainActivity.sendDataToAddPetBanFragment(lastsize);
//                return true;
//
//        }
//        return super.onOptionsItemSelected(item);
//    }

    private void deletePetNuoi(PetNuoi petnuoi){
        new AlertDialog.Builder(mainActivity)
                .setTitle(getString(R.string.app_name))
                .setMessage("Bạn có chắc muốn xóa Pet này không ?")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        DatabaseReference root1 = FirebaseDatabase.getInstance().getReference("Like");
                        root1.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for(DataSnapshot ds : snapshot.getChildren()) {
                                    ds.child(petnuoi.getIdPet()).getRef().removeValue();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });

                        String nameDelete = petnuoi.getNamePet();
                        progressDialog.setMessage("Đang Xóa " + nameDelete);
                        progressDialog.show();
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("PetNuoi");
                        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(petnuoi.getUrlImageIcon());

                        myRef.child(petnuoi.getIdPet()).removeValue(new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
                                //Xoa het toan bo anh trong thu muc.
                                storageReference.delete();

                                //Doi 2 giay.
                                Handler handler = new Handler();
                                handler.postDelayed(() -> {
                                    progressDialog.dismiss();
                                    Toast.makeText(mainActivity,"Đã xóa thành công " + nameDelete,Toast.LENGTH_LONG).show();
                                },2000);
                            }
                        });
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}