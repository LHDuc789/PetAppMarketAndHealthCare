package com.example.khachhang.UserPackage;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.bumptech.glide.Glide;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.Main.SignInActivity;
import com.example.khachhang.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class ADetailCustomerFragment extends Fragment {

    private ImageView ivImg;
    private TextView tvName;
    private TextView tvAddress;
    private TextView tvEmail;
    private TextView tvPhone;
    private Button btnUpdateProfile;
    private Button btnChangePassword;

    private ProgressDialog progressDialog;


    private View DetailView;
    private MainActivity mainActivity;


    public static final String TAG = ADetailCustomerFragment.class.getName();


    public ADetailCustomerFragment() {
        // Required empty public constructor
    }

    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static ADetailCustomerFragment getInstance(Customer customer){
        ADetailCustomerFragment aDetailCustomerFragment = new ADetailCustomerFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_customer",customer);
        aDetailCustomerFragment.setArguments(bundle);
        return aDetailCustomerFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        DetailView = inflater.inflate(R.layout.fragment_a_detail_customer, container, false);
        //Fragment duoc tao tu 1 activity nao do
        //Tra ve activity noi ma Fragment duoc tao.
        mainActivity = (MainActivity) getActivity();
        //Ánh xạ view
        initUI();
        return DetailView;
    }

    private void initUI() {
        ivImg = DetailView.findViewById(R.id.ivImg);
        tvName = DetailView.findViewById(R.id.tvName);
        tvAddress = DetailView.findViewById(R.id.tvAddress);
        tvEmail = DetailView.findViewById(R.id.tvEmail);
        tvPhone = DetailView.findViewById(R.id.tvPhone);
        btnUpdateProfile = DetailView.findViewById(R.id.btnUpdateProfile);
        btnChangePassword = DetailView.findViewById(R.id.btnChangePassword);
        progressDialog = new ProgressDialog(mainActivity);


        //Lay du lieu tu object games ma truyen tu GamesActivity sang gan len cac thuoc tinh Fragment.
        Customer customer = (Customer) getArguments().get("object_customer");
        tvName.setText(customer.getName());
        tvAddress.setText(customer.getAddress());
        tvEmail.setText(customer.getEmail());
        tvPhone.setText(customer.getPhone());
        Glide.with(mainActivity).load(customer.getUrlImageIcon()).error(R.drawable.ic_defaultavatar).into(ivImg);

        btnUpdateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainActivity.sendDataToEditCustomerFragment(customer);
            }
        });

        btnChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mainActivity);
                builder.setTitle("Xác Thực Tài Khoản");

                View viewInflated = LayoutInflater.from(mainActivity).inflate(R.layout.input_dialog_changepassword, null);
                final EditText inputEmail = (EditText) viewInflated.findViewById(R.id.inputEmail);
                final EditText inputPassword = (EditText) viewInflated.findViewById(R.id.inputPassword);
                final EditText inputNewPassword = (EditText) viewInflated.findViewById(R.id.inputNewPassword);

                builder.setView(viewInflated);

                builder.setPositiveButton("Xác Nhận", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        AuthCredential credential = EmailAuthProvider
                                .getCredential(inputEmail.getText().toString().trim(), inputPassword.getText().toString());

                        user.reauthenticate(credential)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful()){
                                            Toast.makeText(mainActivity, "Xác Thực Tài Khoản Thành Công", Toast.LENGTH_SHORT).show();

                                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                            user.updatePassword(inputNewPassword.getText().toString())
                                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {
                                                            if (task.isSuccessful()) {
                                                                progressDialog.setMessage("Đang Đổi Mật Khẩu");
                                                                progressDialog.show();
                                                                Status("offline");
                                                                //Doi 3 giay.
                                                                Handler handler = new Handler();
                                                                handler.postDelayed(() -> {
                                                                    progressDialog.dismiss();
                                                                    FirebaseAuth.getInstance().signOut();
                                                                    Intent intent = new Intent(mainActivity, SignInActivity.class);
                                                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                                    startActivity(intent);
                                                                    mainActivity.finish();
                                                                },3000);
                                                            }

                                                            else {
                                                                try
                                                                {
                                                                    throw task.getException();
                                                                }

                                                                catch (Exception e)
                                                                {
                                                                    Toast.makeText(mainActivity, "Đổi Mật Khẩu Thất Bại.",
                                                                            Toast.LENGTH_SHORT).show();
                                                                }

                                                            }

                                                        }
                                                    });

                                        }

                                        else {
                                            try
                                            {
                                                throw task.getException();
                                            }

                                            catch (Exception e)
                                            {
                                                Toast.makeText(mainActivity, "Xác Thực Thất Bại.",
                                                        Toast.LENGTH_SHORT).show();
                                            }

                                        }

                                    }
                                });
                    }
                });
                builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });
    }



    //An nut add o option menu di khi o trang fragment nay.
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item1 = menu.findItem(R.id.detailAccount);
        if(item1!=null)
            item1.setVisible(false);
    }

    private void Status(String status){
        FirebaseUser user_status = FirebaseAuth.getInstance().getCurrentUser();
        if(user_status!=null){
            DatabaseReference database = FirebaseDatabase.getInstance().getReference("User").child(user_status.getUid());

            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("status", status);

            database.updateChildren(hashMap);
        }
    }

}