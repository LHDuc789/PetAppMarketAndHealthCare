package com.example.khachhang.ShopPackage;

import java.io.Serializable;

public class Profit implements Serializable {
    private String IdBill;
    private String IdUser;
    private String Status;
    private String Name;
    private String Phone;
    private String Address;
    private String Email;
    private String CreateDate;

    public Profit(String IdBill, String IdUser, String Name, String CreateDate, String Phone, String Address, String Email, String Status){
        this.IdBill = IdBill;
        this.IdUser = IdUser;
        this.Name = Name;
        this.CreateDate = CreateDate;
        this.Status = Status;
        this.Phone = Phone;
        this.Address = Address;
        this.Email = Email;
    }
    public Profit(){

    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(String createDate) {
        CreateDate = createDate;
    }

    public String getIdBill() {
        return IdBill;
    }

    public void setIdBill(String idBill) {
        IdBill = idBill;
    }

    public String getIdUser() {
        return IdUser;
    }

    public void setIdUser(String idUser) {
        IdUser = idUser;
    }
}
