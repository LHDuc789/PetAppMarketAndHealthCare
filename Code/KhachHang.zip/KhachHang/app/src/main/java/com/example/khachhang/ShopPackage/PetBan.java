package com.example.khachhang.ShopPackage;

import java.io.Serializable;

public class PetBan implements Serializable {
    private String IdPet;
    private String NameOfType;
    private int Cost;
    private String Des;
    private String UrlImageIcon;
    private String UrlImage1;
    private String UrlImage2;
    private String UrlImage3;

    public PetBan(String idPet, String nameOfType, int cost, String des, String urlImageIcon, String urlImage1, String urlImage2, String urlImage3) {
        IdPet = idPet;
        NameOfType = nameOfType;
        Cost = cost;
        Des = des;
        UrlImageIcon = urlImageIcon;
        UrlImage1 = urlImage1;
        UrlImage2 = urlImage2;
        UrlImage3 = urlImage3;
    }

    public PetBan(){

    }

    public String getIdPet() {
        return IdPet;
    }

    public void setIdPet(String idPet) {
        IdPet = idPet;
    }

    public String getNameOfType() {
        return NameOfType;
    }

    public void setNameOfType(String nameOfType) {
        NameOfType = nameOfType;
    }

    public int getCost() {
        return Cost;
    }

    public void setCost(int cost) {
        Cost = cost;
    }

    public String getDes() {
        return Des;
    }

    public void setDes(String des) {
        Des = des;
    }

    public String getUrlImageIcon() {
        return UrlImageIcon;
    }

    public void setUrlImageIcon(String urlImageIcon) {
        UrlImageIcon = urlImageIcon;
    }

    public String getUrlImage1() {
        return UrlImage1;
    }

    public void setUrlImage1(String urlImage1) {
        UrlImage1 = urlImage1;
    }

    public String getUrlImage2() {
        return UrlImage2;
    }

    public void setUrlImage2(String urlImage2) {
        UrlImage2 = urlImage2;
    }

    public String getUrlImage3() {
        return UrlImage3;
    }

    public void setUrlImage3(String urlImage3) {
        UrlImage3 = urlImage3;
    }
}
