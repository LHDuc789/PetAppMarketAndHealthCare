package com.example.khachhang.UserPackage;

import static android.app.Activity.RESULT_OK;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.bumptech.glide.Glide;
import com.example.khachhang.CartPackage.Cart;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.Main.SignInActivity;
import com.example.khachhang.Main.SignUpActivity;
import com.example.khachhang.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Date;
import java.util.HashMap;


@SuppressWarnings("ALL")
public class EditCustomerFragment extends Fragment {


    private ImageView ivImg;
    private EditText etName;
    private EditText etAddress;
    private EditText etEmail;
    private EditText etPhone;
    private Button btnComplete;
    private Button btnCancel;
    private ProgressDialog progressDialog;

    private Uri uriImageIcon;

    private  String newName, newAddress, newPhone, newEmail, email_re;

    Customer customer;



    private View EditCustomerView;
    private MainActivity mainActivity;

//    private final ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
//        @Override
//        public void onActivityResult(ActivityResult result) {
//            if(result.getResultCode() == RESULT_OK){
//                Intent intent = result.getData();
//                if(intent == null){
//                    return;
//                }
//                uriImageUserIcon = intent.getData();
//                ivImg.setImageURI(uriImageUserIcon);
//            }
//        }
//    });

//    public static final int MY_REQUEST_CODE = 10000;



    public EditCustomerFragment() {
        // Required empty public constructor
    }

    //Lay du lieu object tu Activity de dua sang EditCustomerFragment.
    public static EditCustomerFragment getInstance(Customer customer){
        EditCustomerFragment editCustomerFragment = new EditCustomerFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_edit_customer",customer);
        editCustomerFragment.setArguments(bundle);
        return editCustomerFragment;
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        EditCustomerView = inflater.inflate(R.layout.fragment_edit_customer, container, false);
        mainActivity = (MainActivity) getActivity();

        initUi();
        initListener();
        return EditCustomerView;
    }

    

    private void initUi() {
        progressDialog = new ProgressDialog(mainActivity);
        ivImg = EditCustomerView.findViewById(R.id.ivImg);
        etName = EditCustomerView.findViewById(R.id.etName);
        etAddress = EditCustomerView.findViewById(R.id.etAddress);
        etEmail = EditCustomerView.findViewById(R.id.etEmail);
        etPhone = EditCustomerView.findViewById(R.id.etPhone);
        btnComplete = EditCustomerView.findViewById(R.id.btnComplete);
        btnCancel = EditCustomerView.findViewById(R.id.btnCancel);


        //Lay du lieu tu object games ma truyen tu MainActivity sang gan len cac thuoc tinh Fragment.
        customer = (Customer) getArguments().get("object_edit_customer");
        etName.setText(customer.getName());
        etAddress.setText(customer.getAddress());
        etEmail.setText(customer.getEmail());
        etPhone.setText(customer.getPhone());
        Glide.with(mainActivity).load(customer.getUrlImageIcon()).error(R.drawable.ic_defaultavatar).into(ivImg);

        email_re = etEmail.getText().toString().trim();
    }

    private void initListener() {

        ivImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                onClickPermission();
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, 2022);
            }
        });

        btnComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                newName = etName.getText().toString().trim();
                newAddress = etAddress.getText().toString().trim();
                newPhone = etPhone.getText().toString().trim();
                newEmail = etEmail.getText().toString().trim();

                if(TextUtils.isEmpty(newName)){
                    Toast.makeText(mainActivity, "Vui Lòng Nhập Họ Tên Của Bạn.",
                            Toast.LENGTH_SHORT).show();
                }

                else if(TextUtils.isEmpty(newAddress)){
                    Toast.makeText(mainActivity, "Vui Lòng Nhập Địa Chỉ.",
                            Toast.LENGTH_SHORT).show();
                }

                else if(TextUtils.isEmpty(newEmail)){
                    Toast.makeText(mainActivity, "Vui Lòng Nhập Địa Chỉ Email.",
                            Toast.LENGTH_SHORT).show();
                }

                else if(TextUtils.isEmpty(newPhone)){
                    Toast.makeText(mainActivity, "Vui Lòng Nhập Số Điện Thoại.",
                            Toast.LENGTH_SHORT).show();
                }
                else {

                    AlertDialog.Builder builder = new AlertDialog.Builder(mainActivity);
                    builder.setTitle("Xác Thực Tài Khoản");

                    View viewInflated = LayoutInflater.from(mainActivity).inflate(R.layout.input_dialog_re_auth, null);
                    final EditText inputEmail = (EditText) viewInflated.findViewById(R.id.inputEmail);
                    final EditText inputPassword = (EditText) viewInflated.findViewById(R.id.inputPassword);

                    builder.setView(viewInflated);

                    builder.setPositiveButton("Xác Nhận", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            AuthCredential credential = EmailAuthProvider
                                    .getCredential(inputEmail.getText().toString().trim(), inputPassword.getText().toString());

                            user.reauthenticate(credential)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()){
                                                Toast.makeText(mainActivity, "Xác Thực Tài Khoản Thành Công", Toast.LENGTH_SHORT).show();
                                                progressDialog.setMessage("Đang Cập Nhật Thông Tin");
                                                progressDialog.show();
                                                Status("offline");

                                                updateProfile();

                                                //Doi 3 giay.
                                                Handler handler = new Handler();
                                                handler.postDelayed(() -> {
                                                    progressDialog.dismiss();
                                                    FirebaseAuth.getInstance().signOut();
                                                    Intent intent = new Intent(mainActivity, SignInActivity.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                    startActivity(intent);
                                                    mainActivity.finish();
                                                },3000);
                                            }

                                            else {
                                                try
                                                {
                                                    throw task.getException();
                                                }
                                                // if user enters wrong email.

                                                catch (Exception e)
                                                {
                                                    Toast.makeText(mainActivity, "Xác Thực Thất Bại.",
                                                            Toast.LENGTH_SHORT).show();
                                                }

                                            }

                                        }
                                    });
                        }
                    });
                    builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                    builder.show();

                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fmManager = getActivity().getSupportFragmentManager();
                fmManager.popBackStack();
            }
        });
    }

    //Ham tra ve ket qua va phan hoi de dua anh len ImageView.
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2022 && resultCode == RESULT_OK && data != null) {
            uriImageIcon = data.getData();
            ivImg.setImageURI(uriImageIcon);
            uploadToFireBase(uriImageIcon, customer);
        }
    }

    private void Status(String status){
        FirebaseUser user_status = FirebaseAuth.getInstance().getCurrentUser();
        if(user_status!=null){
            DatabaseReference database = FirebaseDatabase.getInstance().getReference("User").child(user_status.getUid());

            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("status", status);

            database.updateChildren(hashMap);
        }
    }
//    private void onClickPermission() {
//
//        if(mainActivity == null){
//            return;
//        }
//
//        //Yeu Cau Request Permission tu Android 6 tro len. Duoi thi khong can
//        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.M){
//            openGallery();
//            return;
//        }
//
//        if(getActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
//            openGallery();
//        }
//
//        else {
//            String [] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
//            getActivity().requestPermissions(permissions, MY_REQUEST_CODE);
//        }
//    }


//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == MY_REQUEST_CODE){
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
//                openGallery();
//            }
//            else{
//                Toast.makeText(mainActivity,"Vui lòng cấp quyền truy cập ảnh cho ứng dụng",Toast.LENGTH_LONG).show();
//            }
//        }
//    }


//    private void openGallery() {
//        Intent intent = new Intent();
//        intent.setType("image/*");
//        intent.setAction(Intent.ACTION_GET_CONTENT);
//        activityResultLauncher.launch(Intent.createChooser(intent, "Chọn Ảnh Đại Diện"));
//    }


    private void updateProfile(){
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        user.updateEmail(newEmail)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            customer.setName(newName);
                            customer.setAddress(newAddress);
                            customer.setPhone(newPhone);
                            customer.setEmail(newEmail);

                            DatabaseReference root = FirebaseDatabase.getInstance().getReference("User");
                            root.child(user.getUid()).setValue(customer);
                            Handler handler = new Handler();
                            handler.postDelayed(() -> {
                                Toast.makeText(mainActivity,"Cập Nhật Thông Tin Thành Công",Toast.LENGTH_LONG).show();
                            },2000);
                        }
                        else {
                            try
                            {
                                throw task.getException();
                            }
                            catch (FirebaseAuthInvalidCredentialsException malformedEmail)
                            {
                                Toast.makeText(mainActivity, "Email Không Họp Lệ.",
                                        Toast.LENGTH_SHORT).show();
                            }
                            catch (FirebaseAuthUserCollisionException existEmail)
                            {
                                Toast.makeText(mainActivity, "Email Này Đã Được Sử Dụng.",
                                        Toast.LENGTH_SHORT).show();
                            }
                            catch (Exception e)
                            {
                                Toast.makeText(mainActivity, "Cập Nhật Thông Tin Thất Bại.",
                                        Toast.LENGTH_SHORT).show();
                            }

                        }
                    }
                });

    }


    private void uploadToFireBase(Uri uriImage, Customer customer) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("User").child(customer.getEmail());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage));

        if(customer.getUrlImageIcon().equals("https://firebasestorage.googleapis.com/v0/b/petdatabase-c0f2c.appspot.com/o/default%2Fic_defaultavatar.png?alt=media&token=ca253e3e-b6ca-45d8-8d96-a50d8173811b") == false){
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(customer.getUrlImageIcon());
            storageReference.delete();
        }


        progressDialog.setMessage("Đang Cập Nhật Ảnh Đại Diện");
        progressDialog.show();
        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                customer.setUrlImageIcon(String.valueOf(uri1));
                progressDialog.dismiss();
                Toast.makeText(mainActivity,"Cập Nhật Ảnh Đại Diện Thành Công",Toast.LENGTH_LONG).show();
            });
        });

    }

    //Ham dat ten cho file anh khi upload len Storage.
    private String getFileExtension(Uri mUri) {
        ContentResolver cr = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));
    }

}