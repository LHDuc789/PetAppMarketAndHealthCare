package com.example.khachhang.CarePackage;

import static android.app.Activity.RESULT_OK;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;


@SuppressWarnings("ALL")
public class AddPetNuoiFragment extends Fragment {

    private EditText etNamePet;
    private EditText etNameOfType;

    private Button btnComplete;
    private Button btnCancel;

    private MainActivity mainActivity;
    private View AddPetNuoiView;
    private ImageView ivImg;
    private Uri uriImageIcon;


    private ProgressDialog progressDialog;

    PetNuoi newPetNuoi = new PetNuoi("","","","",false,false,false,false,false,"",0);
    FirebaseUser user;

    public static final String TAG = AddPetNuoiFragment.class.getName();

    public AddPetNuoiFragment() {
        // Required empty public constructor
    }

    public static AddPetNuoiFragment getInstance(int size){
        AddPetNuoiFragment addPetNuoiFragment = new AddPetNuoiFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("totalSize",size);
        addPetNuoiFragment.setArguments(bundle);
        return addPetNuoiFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        AddPetNuoiView =  inflater.inflate(R.layout.fragment_add_pet_nuoi, container, false);
        mainActivity = (MainActivity) getActivity();
        user = FirebaseAuth.getInstance().getCurrentUser();

        //Ánh xạ view
        initUI();
        initPhotoListener();
        initButtonListener();
        return AddPetNuoiView;
    }

    private void initUI() {
        mainActivity = (MainActivity) getActivity();
        progressDialog = new ProgressDialog(mainActivity);


        etNamePet = AddPetNuoiView.findViewById(R.id.etNamePet);
        etNameOfType = AddPetNuoiView.findViewById(R.id.etNameOfType);
        ivImg = AddPetNuoiView.findViewById(R.id.ivImg);
        btnCancel = AddPetNuoiView.findViewById(R.id.btnCancel);
        btnComplete = AddPetNuoiView.findViewById(R.id.btnComplete);
    }

    private void initButtonListener(){
        btnComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newNamePet = etNamePet.getText().toString().trim();
                String newNameOfType = etNameOfType.getText().toString().trim();

                if(uriImageIcon == null){
                    Toast.makeText(mainActivity,"Vui Lòng Không Để Trống Ảnh Đại Diện Của Thú Cưng.",Toast.LENGTH_LONG).show();
                }

                else if(newNamePet.isEmpty()){
                    Toast.makeText(mainActivity,"Vui Lòng Nhập Tên Thú Cưng", Toast.LENGTH_LONG).show();
                }

                else if(newNameOfType.isEmpty()){
                    Toast.makeText(mainActivity,"Vui Lòng Nhập Tên Loài Thú Cưng", Toast.LENGTH_LONG).show();
                }

                else{
                    int totalSize = (int) getArguments().get("totalSize");
                    String idPet;
                    if((totalSize+1)<10){
                        idPet = "PN0" + (totalSize+1);
                    }
                    else {
                        idPet = "PN" + (totalSize+1);
                    }

                    newPetNuoi.setIdPet(idPet);
                    newPetNuoi.setIdUser(user.getUid());
                    newPetNuoi.setNamePet(newNamePet);
                    newPetNuoi.setNameOfType(newNameOfType);

                    DatabaseReference root = FirebaseDatabase.getInstance().getReference("PetNuoi");
                    root.child(String.valueOf(newPetNuoi.getIdPet())).setValue(newPetNuoi);

                    DatabaseReference root1 = FirebaseDatabase.getInstance().getReference("Like");
                    root1.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for(DataSnapshot ds : snapshot.getChildren()) {
                                ds.child(idPet).getRef().setValue(false);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                    progressDialog.setMessage("Đang Thêm Một Thú Cưng Mới");
                    progressDialog.show();

                    //Doi 3 giay.
                    Handler handler = new Handler();
                    handler.postDelayed(() -> {
                        progressDialog.dismiss();
//                        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
//                        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
//                        fragmentTransaction.replace(R.id.root_view, new PetFragment());
//                        //Back lai content_frame ma van luu trang thai truoc.
//                        fragmentTransaction.addToBackStack(null);
//                        fragmentTransaction.commit();
                        Toast.makeText(mainActivity,"Thêm Thành Công Đối Tượng " + newPetNuoi.getNamePet(),Toast.LENGTH_LONG).show();
                        FragmentManager fmManager = getActivity().getSupportFragmentManager();
                        fmManager.popBackStack();
                    },2000);
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
                if(!newPetNuoi.getUrlImageIcon().isEmpty()){
                    StorageReference storageReference = firebaseStorage.getReferenceFromUrl(newPetNuoi.getUrlImageIcon());
                    storageReference.delete();
                    newPetNuoi.setUrlImageIcon("");
                }
                if(newPetNuoi.getUrlImageIcon().isEmpty()) {
                    FragmentManager fmManager = getActivity().getSupportFragmentManager();
                    fmManager.popBackStack();
                }
            }
        });
    }

    private void initPhotoListener(){
        //Lay anh tu dien thoai up len ImageView co id la ivImg.
        ivImg.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 2);
        });
    }



    private void uploadToFireBase(Uri uriImage, FirebaseUser user, PetNuoi petnuoi) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetNuoi").child(user.getEmail());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage));

        if(!petnuoi.getUrlImageIcon().equals("")){
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(petnuoi.getUrlImageIcon());
            storageReference.delete();
        }

        progressDialog.setMessage("Đang Thêm Ảnh Đại Diện Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                petnuoi.setUrlImageIcon(String.valueOf(uri1));
                progressDialog.dismiss();
                Toast.makeText(mainActivity,"Thêm Thành Công Ảnh Đại Diện Cho Thú Cưng.",Toast.LENGTH_LONG).show();
            });
        });
    }

    //Ham dat ten cho file anh khi upload len Storage.
    private String getFileExtension(Uri mUri) {
        ContentResolver cr = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));
    }

    //Ham tra ve ket qua va phan hoi de dua anh len ImageView.
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==2 && resultCode == RESULT_OK && data != null){
            uriImageIcon = data.getData();
            ivImg.setImageURI(uriImageIcon);
            uploadToFireBase(uriImageIcon,user, newPetNuoi);
        }

    }



}