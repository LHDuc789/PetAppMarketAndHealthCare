package com.example.khachhang.ChatPackage;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DirectAction;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Path;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.example.khachhang.Interface.ClickItemPetNuoi;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.Notifications.Token;
import com.example.khachhang.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;


public class ChatFragment extends Fragment {

    private View mView;
    private RecyclerView rcvPetNuoi;
    private MainActivity mainActivity;
    ArrayList<PetNuoi> petnuois;
    PetNuoiAdapter petNuoiAdapter;
    private FrameLayout rootView;
    FirebaseUser user;


    public ChatFragment() {
        // Required empty public constructor
    }


//    public static PetFragment newInstance() {
//        PetFragment fragment = new PetFragment();
//        return fragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//
//        }
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_chat, container, false);
        initUi();
        getPetNuoiListFromRealtimeDataBase();
        updateToken(FirebaseInstanceId.getInstance().getToken());
        return mView;
    }

    public void initUi(){
        //Khoi tao gamesActivity de su dung.
        mainActivity = (MainActivity) getActivity();

//        rootView = mView.findViewById(R.id.apps_root_view);
        rcvPetNuoi = mView.findViewById(R.id.PetNuoiList);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mainActivity);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        rcvPetNuoi.setLayoutManager(linearLayoutManager);

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mainActivity,DividerItemDecoration.VERTICAL);
        rcvPetNuoi.addItemDecoration(itemDecoration);

        petnuois = new ArrayList<>();

        petNuoiAdapter = new PetNuoiAdapter(mainActivity, petnuois);

        rcvPetNuoi.setAdapter(petNuoiAdapter);

        //Gan Option Menu len Fragment.
        setHasOptionsMenu(true);

    }


    public void getPetNuoiListFromRealtimeDataBase() {

        user = FirebaseAuth.getInstance().getCurrentUser();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("PetNuoi");
        Query queryByToTalLike = myRef.orderByChild("totalLike");
        //Add tat ca du lieu len firebase.
//        myRef.setValue(games, new DatabaseReference.CompletionListener() {
//            @Override
//            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
//                Toast.makeText(gamesActivity,"Add all games success",Toast.LENGTH_LONG).show();
//            }
//        });


        queryByToTalLike.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        petnuois.clear();
                        for (DataSnapshot snapshot1 : snapshot.getChildren()){
                            PetNuoi petNuoi = snapshot1.getValue(PetNuoi.class);
                            petnuois.add(petNuoi);
                        }
                        petNuoiAdapter.notifyDataSetChanged();
                    }
                },1000);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    private void updateToken(String token){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tokens");
        Token token1 = new Token(token);
        reference.child(user.getUid()).setValue(token1);
    }

}