package com.example.khachhang.CartPackage;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.khachhang.CartPackage.Cart;
import com.example.khachhang.Interface.ClickItemPetBan;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.R;
import com.example.khachhang.ShopPackage.PetBan;
import com.example.khachhang.UserPackage.Customer;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder>{
    private List<Cart> mCart;
    private final Context mContext;
    private final ClickItemPetBan clickItemPetBanListener;
    private int lastsize;
    private String IdCart;
    private String IdUser;


    public CartAdapter(Context mContext, List _carts, ClickItemPetBan listener){
        this.mContext = mContext;
        this.mCart = _carts;
        this.clickItemPetBanListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View petbanView = inflater.inflate(R.layout.cart_item,parent,false);
        return new ViewHolder(petbanView);
    }

    @SuppressLint("DefaultLocale")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Lay ra vi tri cua thang object Games bat ki khi duoc click
        final Cart cart = (Cart) mCart.get(position);
        if (cart == null){
            return;
        }

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("PetBan");

        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                PetBan c = snapshot.getValue(PetBan.class);
                if(c!=null && cart.getIdPetBan().equals(c.getIdPet())){
                    holder.tvName.setText(c.getNameOfType());
                    holder.tvCost.setText("Giá Tiền: " + c.getCost() + " VND");
                    holder.tvNumber.setText("Số Lượng: " + cart.getNumber());
                    //Su dung thu vien Glide de load anh lay tu firebase ve.
                    Glide.with(mContext).load(c.getUrlImageIcon()).into(holder.ivImg);
//        holder.ivImg.setImageResource(games.getImg());

                    holder.CartListItem.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            clickItemPetBanListener.onClickItemPetBan(c);
                        }
                    });

                    holder.btnCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            clickItemPetBanListener.onClickDeleteCart(cart);
                        }
                    });
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


//        holder.btnBuy.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                FirebaseDatabase database = FirebaseDatabase.getInstance();
//                DatabaseReference myRef_re = database.getReference("Cart");
//
//                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//                DatabaseReference myRef = database.getReference("User");
//
//                //Lay ra phan tu cuoi cung cua Cart.
//                myRef_re.orderByKey().limitToLast(1).addChildEventListener(new ChildEventListener() {
//                    @Override
//                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
//                        String d = snapshot.getKey();
//                        if (d != null) {
//                            //Chi lay phan so cua IdUser
//                            String[] part = d.split("(?<=\\D)(?=\\d)");
//                            lastsize = Integer.parseInt(part[1]);
//                        }
//                    }
//
//                    @Override
//                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
//
//                    }
//
//                    @Override
//                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {
//
//                    }
//
//                    @Override
//                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
//
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//
//                });
//
//                //Lay ra IdUser hien tai.
//                myRef.addChildEventListener(new ChildEventListener() {
//                    @Override
//                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
//                        //Lay ra Parent Key cua User.
//                        String IdParentUser = snapshot.getKey();
//                        if(IdParentUser!=null && IdParentUser.equals(user.getUid())){
//                            Customer c = snapshot.getValue(Customer.class);
//                            if (c != null) {
//                                IdUser = c.getIdUser();
//                            }
//                        }
//
//                    }
//
//                    @Override
//                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
//
//                    }
//
//                    @Override
//                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {
//
//                    }
//
//                    @Override
//                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
//
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//                });
//
//                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
//                builder.setTitle(petban.getNameOfType());
//
//                View viewInflated = LayoutInflater.from(mContext).inflate(R.layout.input_dialog, null);
//                final EditText input = (EditText) viewInflated.findViewById(R.id.inputNumber);
//
//                builder.setView(viewInflated);
//
//                builder.setPositiveButton("Xác Nhận", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        if((lastsize+1)<10){
//                            IdCart = "C0" + (lastsize+1);
//                        }
//                        else{
//                            IdCart = "C" + (lastsize+1);
//                        }
//                        dialog.dismiss();
//                        m_Text = input.getText().toString();
//                        int number = Integer.parseInt(m_Text);
//                        Cart cart = new Cart(petban.getIdPet(),IdUser,number);
//                        DatabaseReference root = FirebaseDatabase.getInstance().getReference("Cart");
//                        root.child(String.valueOf(IdCart)).setValue(cart);
//                        Toast.makeText(mContext,"Thêm Vào Giỏ Hàng Thành Công",Toast.LENGTH_LONG).show();
//                    }
//                });
//                builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        dialog.cancel();
//                    }
//                });
//
//                builder.show();
//            }
//        });
//




    }

    @Override
    public int getItemCount() {
        return mCart.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvName;
        public TextView tvCost;
        public TextView tvNumber;
        public ImageView ivImg;
        public LinearLayout CartListItem;
        public Button btnCancel;

        public ViewHolder(View itemView) {
            super(itemView);
            ivImg = itemView.findViewById(R.id.ivImg);
            tvName = itemView.findViewById(R.id.tvName);
            tvCost = itemView.findViewById(R.id.tvCost);
            tvNumber = itemView.findViewById(R.id.tvNubmer);
            CartListItem = itemView.findViewById(R.id.CartListItem);
            btnCancel = itemView.findViewById(R.id.btnCancel);
        }
    }
}
