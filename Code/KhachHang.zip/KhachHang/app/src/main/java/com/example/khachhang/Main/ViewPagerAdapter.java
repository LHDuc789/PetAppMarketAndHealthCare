package com.example.khachhang.Main;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.khachhang.CarePackage.CareFragment;
import com.example.khachhang.ChatPackage.ChatFragment;
import com.example.khachhang.ShopPackage.ShopFragment;

@SuppressWarnings("deprecation")
public class ViewPagerAdapter extends FragmentStatePagerAdapter {
    public ViewPagerAdapter(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new ShopFragment();
            case 1:
                return new CareFragment();
            case 2:
                return new ChatFragment();
            default:
                return new ShopFragment();
        }
    }

    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String title = "";
        switch (position){
            case 0:
                title = "Shop";
                break;
            case 1:
                title = "Care";
                break;
            case 2:
                title = "Chat";
                break;
        }
        return title;
    }
}