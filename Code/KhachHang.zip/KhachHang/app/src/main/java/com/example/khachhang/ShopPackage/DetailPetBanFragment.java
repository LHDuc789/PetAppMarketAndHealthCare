package com.example.khachhang.ShopPackage;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.bumptech.glide.Glide;

import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.Photo.PhotoAdapter;
import com.example.khachhang.R;

import java.util.ArrayList;

import me.relex.circleindicator.CircleIndicator3;


public class DetailPetBanFragment extends Fragment {


    private ImageView ivImg;
    private TextView tvNameOfType;
    private TextView tvDes;
    private TextView tvCost;

    private View DetailView;
    private MainActivity mainActivity;

    ArrayList<String> photo_list;

    private ViewPager2 mViewPager2;
    private CircleIndicator3 mCircleIndicator3;

    public static final String TAG = DetailPetBanFragment.class.getName();


    public DetailPetBanFragment() {
        // Required empty public constructor
    }

    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static DetailPetBanFragment getInstance(PetBan petban){
        DetailPetBanFragment detailPetBanFragment = new DetailPetBanFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_petban", petban);
        detailPetBanFragment.setArguments(bundle);
        return detailPetBanFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        DetailView = inflater.inflate(R.layout.fragment_detail_pet_ban, container, false);
        //Fragment duoc tao tu 1 activity nao do
        //Tra ve activity noi ma Fragment duoc tao.
        mainActivity = (MainActivity) getActivity();
        //Ánh xạ view
        initUI();
        return DetailView;
    }

    @SuppressLint("SetTextI18n")
    private void initUI() {
        ivImg = DetailView.findViewById(R.id.ivImg);
        tvNameOfType = DetailView.findViewById(R.id.tvNameOfType);
        tvDes = DetailView.findViewById(R.id.tvDes);
        tvCost = DetailView.findViewById(R.id.tvCost);

        mViewPager2 = DetailView.findViewById(R.id.view_pager_2);
        mCircleIndicator3 = DetailView.findViewById(R.id.circle_indicator_3);


        //Lay du lieu tu object games ma truyen tu GamesActivity sang gan len cac thuoc tinh Fragment.
        PetBan petban = (PetBan) getArguments().get("object_petban");
        tvNameOfType.setText(petban.getNameOfType());
        tvDes.setText(petban.getDes());
        tvCost.setText(String.valueOf(petban.getCost()));
        Glide.with(mainActivity).load(petban.getUrlImageIcon()).into(ivImg);


        //Tao ra mot ArrayList moi de chua nhung UrlImg co san trong game.
        photo_list = new ArrayList<>();
        photo_list.add(petban.getUrlImage1());
        photo_list.add(petban.getUrlImage2());
        photo_list.add(petban.getUrlImage3());

        //Khoi tao Adapter.
        PhotoAdapter photoAdapter = new PhotoAdapter(mainActivity,photo_list);

        //Gan hoac load adpater len mViewPage2.
        mViewPager2.setAdapter(photoAdapter);
        //Gan mCircleIndicator3 cho mViewPager2.
        mCircleIndicator3.setViewPager(mViewPager2);
    }
}