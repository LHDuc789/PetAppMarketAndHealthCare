package com.example.khachhang.CarePackage;

import static android.app.Activity.RESULT_OK;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;


public class EditPetNuoiFragment extends Fragment {


    private MainActivity mainActivity;

    private View EditPetNuoiFragment;

    private ImageView ivImg;

    private ProgressDialog progressDialog;
    private TextView etNamePet;
    private TextView etNameOfType;

    private Button btnEdit;
    private Button btnCancel;

    private Uri uriImageIcon;
    private Uri uriImageIcon_re;

    String urlImage;

    ArrayList<String> listUrlImage;

    PetNuoi petnuoi;
    FirebaseUser user;



//    public static final String TAG = EditPetBanFragment.class.getName();


    public EditPetNuoiFragment() {
        // Required empty public constructor
    }


    //Lay du lieu object tu Activity de dua sang DetailFragment.
    public static EditPetNuoiFragment getInstance(PetNuoi petnuoi){
        EditPetNuoiFragment editPetNuoiFragment = new EditPetNuoiFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("object_petnuoi", petnuoi);
        editPetNuoiFragment.setArguments(bundle);
        return editPetNuoiFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        EditPetNuoiFragment =  inflater.inflate(R.layout.fragment_edit_pet_nuoi, container, false);
        mainActivity = (MainActivity) getActivity();
        user = FirebaseAuth.getInstance().getCurrentUser();

        //Ánh xạ view
        initUI();
        initButtonListener();
        initPhotoListener();
        return EditPetNuoiFragment;
    }

    private void initPhotoListener() {
        //Lay anh tu dien thoai up len ImageView co id la ivImg.
        ivImg.setOnClickListener(view -> {
            Intent galleryIntent = new Intent();
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, 2);
        });
    }

    private void initUI() {
        listUrlImage = new ArrayList<>();
        progressDialog = new ProgressDialog(mainActivity);


        etNamePet = EditPetNuoiFragment.findViewById(R.id.etNamePet);
        etNameOfType = EditPetNuoiFragment.findViewById(R.id.etNameOfType);
        ivImg = EditPetNuoiFragment.findViewById(R.id.ivImg);

        btnEdit = EditPetNuoiFragment.findViewById(R.id.btnEdit);
        btnCancel = EditPetNuoiFragment.findViewById(R.id.btnCancel);

        petnuoi = (PetNuoi) getArguments().get("object_petnuoi");

        etNamePet.setText(petnuoi.getNamePet());
        etNameOfType.setText(petnuoi.getNameOfType());
        Glide.with(mainActivity).load(petnuoi.getUrlImageIcon()).into(ivImg);

        urlImage = petnuoi.getUrlImageIcon();
        listUrlImage.add(urlImage);
    }

    private void initButtonListener(){
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String newNamePet = etNamePet.getText().toString().trim();
                String newNameOfType = etNameOfType.getText().toString().trim();

                petnuoi.setNamePet(newNamePet);
                petnuoi.setNameOfType(newNameOfType);

                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();

                if(!petnuoi.getUrlImageIcon().equals(urlImage)){
                    for(int ck1 = 0; ck1 < listUrlImage.size()-1; ck1++){
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage.get(ck1));
                        storageReference.delete();
                    }
                    urlImage = petnuoi.getUrlImageIcon();
                }


                if(petnuoi.getUrlImageIcon().equals(urlImage)){
                    //Goi Database voi parent key la PetBan.
                    DatabaseReference root = FirebaseDatabase.getInstance().getReference("PetNuoi");
                    root.child(String.valueOf(petnuoi.getIdPet())).setValue(petnuoi);

                    progressDialog.setMessage("Đang Cập Nhật Lại Thông Tin Mới Cho Thú Cưng");
                    progressDialog.show();

                    //Doi 2 giay.
                    Handler handler = new Handler();
                    handler.postDelayed(() -> {
                        progressDialog.dismiss();

//                        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
//                        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
//                        fragmentTransaction.replace(R.id.root_view, new PetFragment());
//                        //Back lai content_frame ma van luu trang thai truoc.
//                        fragmentTransaction.addToBackStack(null);
//                        fragmentTransaction.commit();
                        Toast.makeText(mainActivity,"Cập Nhật Thành Công " + petnuoi.getNamePet(),Toast.LENGTH_LONG).show();

                        FragmentManager fmManager = getActivity().getSupportFragmentManager();
                        fmManager.popBackStack();
                    },2000);
                }




            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();

                if(!petnuoi.getUrlImageIcon().equals(urlImage)){
                    for(int ck1 = 1; ck1 < listUrlImage.size(); ck1++){
                        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(listUrlImage.get(ck1));
                        storageReference.delete();
                    }
                    petnuoi.setUrlImageIcon(urlImage);
                }

                if(petnuoi.getUrlImageIcon().equals(urlImage)) {
                    FragmentManager fmManager = getActivity().getSupportFragmentManager();
                    fmManager.popBackStack();
                }
            }
        });


    }

    private void uploadToFireBase(Uri uriImage, FirebaseUser user, PetNuoi petnuoi) {
        //Goi Storage voi parent key la PetBan.
        StorageReference reference = FirebaseStorage.getInstance().getReference().child("PetNuoi").child(user.getEmail());

        //Goi Storage cua reference voi child key la System.currentTimeMillis() + "." + getFileExtension(uri).
        StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(uriImage));

        progressDialog.setMessage("Đang Cập Nhật Lại Ảnh Đại Diện Cho Thú Cưng.");
        progressDialog.show();

        //Xu ly su kien thanh cong khi upload image len Storage.
        fileRef.putFile(uriImage).addOnSuccessListener(taskSnapshot -> {
            //Lay lai duong dan cua URL ma Url hoi nay da duoc tao.
            fileRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                progressDialog.dismiss();
                petnuoi.setUrlImageIcon(String.valueOf(uri1));
                listUrlImage.add(String.valueOf(uri1));
                Toast.makeText(mainActivity,"Cập Nhật Thành Công Ảnh Đại Diện Cho Thú Cưng.",Toast.LENGTH_LONG).show();
            });
        });
    }

    //Ham dat ten cho file anh khi upload len Storage.
    private String getFileExtension(Uri mUri) {
        ContentResolver cr = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));
    }

    //Ham tra ve ket qua va phan hoi de dua anh len ImageView.
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==2 && resultCode == RESULT_OK && data != null){
            uriImageIcon = data.getData();
            ivImg.setImageURI(uriImageIcon);
            uploadToFireBase(uriImageIcon, user, petnuoi);
        }


    }





}