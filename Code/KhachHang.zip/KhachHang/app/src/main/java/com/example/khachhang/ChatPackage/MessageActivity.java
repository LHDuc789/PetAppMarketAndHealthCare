package com.example.khachhang.ChatPackage;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.Notifications.Client;
import com.example.khachhang.Notifications.Data;
import com.example.khachhang.Notifications.MyResponse;
import com.example.khachhang.Notifications.Sender;
import com.example.khachhang.Notifications.Token;
import com.example.khachhang.R;
import com.example.khachhang.UserPackage.Customer;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MessageActivity extends AppCompatActivity {

    private CircleImageView ivImg;
    private TextView tvUserName;
    private ImageButton btnSend;
    private EditText etSend;
    private ImageView ivStatusOn;
    private ImageView ivStatusOff;


    Intent intent;
    String idUser;
    FirebaseUser user;

    MessageAdapter messageAdapter;
    List<Chat> mChat;
    RecyclerView recyclerView;

    APIService apiService;

    boolean notify = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        initUI();
        getDataUserChat();
        initButtonListener();
    }

    public void initUI(){
        user = FirebaseAuth.getInstance().getCurrentUser();

        Toolbar toolbar = findViewById(R.id.toolBar);
        ivImg = findViewById(R.id.ivImg);
        tvUserName = findViewById(R.id.tvUserName);
        btnSend = findViewById(R.id.btnSend);
        etSend = findViewById(R.id.etSend);

        ivStatusOn = findViewById(R.id.ivStatusOn);
        ivStatusOff = findViewById(R.id.ivStatusOff);

        recyclerView = findViewById(R.id.rcvChat);
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);


        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.check = 0;
                startActivity(new Intent(MessageActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        apiService = Client.getClient("https://fcm.googleapis.com/").create(APIService.class);

    }

    public void getDataUserChat(){
        intent = getIntent();
        idUser = intent.getStringExtra("idUser");
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef_re = database.getReference("User").child(idUser);

        myRef_re.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Customer customer = snapshot.getValue(Customer.class);
                if(customer!=null){
                    tvUserName.setText(customer.getName());
                    Glide.with(getApplicationContext()).load(customer.getUrlImageIcon()).into(ivImg);
                    readMessage(user.getUid(),idUser,customer.getUrlImageIcon());
                    if (customer.getStatus().equals("online")) {
                        ivStatusOn.setVisibility(View.VISIBLE);
                        ivStatusOff.setVisibility(View.GONE);
                    } else {
                        ivStatusOn.setVisibility(View.GONE);
                        ivStatusOff.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void initButtonListener(){
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notify = true;
                String msg = etSend.getText().toString();
                if(!msg.equals("")){
                    sendMessage(user.getUid(),idUser,msg);
                }
                else {
                    Toast.makeText(MessageActivity.this, "Không Thể Gửi Tin Nhắn Trống !!!", Toast.LENGTH_SHORT).show();
                }
                etSend.setText("");
            }
        });
    }

    private void sendMessage(String sender, String receiver, String message){
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("sender",sender);
        hashMap.put("receiver",receiver);
        hashMap.put("message",message);

        database.child("Chats").push().setValue(hashMap);


        final String msg = message;

        database = FirebaseDatabase.getInstance().getReference("User").child(user.getUid());
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Customer customer = dataSnapshot.getValue(Customer.class);
                if (notify) {
                    assert customer != null;
                    sendNotification(receiver, customer.getName(), msg);
                }
                notify = false;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void sendNotification(String receiver, String username, String message){
        DatabaseReference tokens = FirebaseDatabase.getInstance().getReference("Tokens");
        Query query = tokens.orderByKey().equalTo(receiver);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot1 : snapshot.getChildren()){
                    Token token = snapshot1.getValue(Token.class);
                    Data data = new Data(user.getUid(), R.drawable.ic_app, username+": " +message, "Tin Nhắn Mới",idUser);


                    Sender sender = new Sender(data, token.getToken());
                    apiService.sendNotification(sender)
                            .enqueue(new Callback<MyResponse>() {
                                @Override
                                public void onResponse(Call<MyResponse> call, Response<MyResponse> response) {
                                    if(response.code() == 200){
                                        if(response.body().success != 1){
                                            Toast.makeText(MessageActivity.this, "Có Lỗi Xảy Ra", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }

                                @Override
                                public void onFailure(Call<MyResponse> call, Throwable t) {

                                }
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void readMessage(String Id, String IdUser, String urlImageIcon){
        mChat = new ArrayList<>();
        DatabaseReference database = FirebaseDatabase.getInstance().getReference("Chats");
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mChat.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()){
                    Chat chat = snapshot1.getValue(Chat.class);
                    if(chat.getReceiver().equals(Id) && chat.getSender().equals(IdUser) || chat.getReceiver().equals(IdUser) && chat.getSender().equals(Id)){
                        mChat.add(chat);
                    }

                    messageAdapter = new MessageAdapter(MessageActivity.this, mChat, urlImageIcon);
                    recyclerView.setAdapter(messageAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void Status(String status){
        FirebaseUser user_status = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference database = FirebaseDatabase.getInstance().getReference("User").child(user_status.getUid());

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("status", status);

        database.updateChildren(hashMap);
    }

    @Override
    protected void onResume() {
        super.onResume();
        MainActivity.check = 1;
        Status("online");
    }

//    @Override
//    protected void onPause() {
//        super.onPause();
//        Status("online");
//    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MainActivity.check = 0;
    }

    @Override
    protected void onPause() {
        super.onPause();
        MainActivity.check = 0;
        Status("offline");

    }

//    @Override
//    protected void onStop() {
//        super.onStop();
//        if(checkOut == 1){
//            MainActivity.check = 0;
//        }
//        else{
//            checkOut = 0;
//            MainActivity.check = 0;
//            Status("offline");
//        }
//    }

}