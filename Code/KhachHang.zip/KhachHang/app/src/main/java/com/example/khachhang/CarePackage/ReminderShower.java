package com.example.khachhang.CarePackage;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.khachhang.Main.SplashActivity;
import com.example.khachhang.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class ReminderShower extends BroadcastReceiver {

    public static String nameOfPetPublic;
    public static int CodeSend;

    @Override
    public void onReceive(Context context, Intent intent) {
        String nameOfPet = intent.getStringExtra("namePet");
        nameOfPetPublic = nameOfPet;
        int ID = intent.getIntExtra("idCn", 400);
        String idPetNuoi = intent.getStringExtra("stateShowerID");

        Intent resultIntent = new Intent(context, SplashActivity.class);
        PendingIntent resultPendingIntent = PendingIntent.getActivity(context,1,resultIntent,PendingIntent.FLAG_MUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context,"checkDateTimeStateShower")
                .setSmallIcon(R.drawable.ic_app)
                .setContentTitle("Nhắc Nhở Đi Tắm Cho Thú Cưng " + nameOfPet)
                .setContentText("Đã Tới Hẹn Đi Tắm Cho Thú Cưng")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(resultPendingIntent);

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(context);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("PetNuoi");
        myRef.child(idPetNuoi).child("stateShower").setValue(false);

        notificationManagerCompat.notify(ID,builder.build());
    }


}
