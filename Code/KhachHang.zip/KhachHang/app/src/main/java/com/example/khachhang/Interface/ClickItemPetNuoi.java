package com.example.khachhang.Interface;

import com.example.khachhang.CarePackage.PetNuoi;

public interface ClickItemPetNuoi {
    void onClickItemPetNuoi(PetNuoi petNuoi);
    void onClickDeletePetNuoi(PetNuoi petNuoi);
    void onClickEditPetNuoi(PetNuoi petNuoi);
}
