package com.example.khachhang.Photo;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import java.util.List;

public class PhotoAdapter extends FragmentStateAdapter {

    //Bat buoc phai la dang List thi moi dua len Adapter duoc.
    private List mList;

    public PhotoAdapter(@NonNull FragmentActivity fragmentActivity, List list) {
        super(fragmentActivity);
        this.mList = list;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        //Lay ve mot urlImg_Slide cua object Games duoc chi dinh tai mot vi tri nhat dinh (0,1,2,..).
        String urlImg_Slide = (String) mList.get(position);

        //Gui urlImg_Slide qua PhotoFragment de xu ly.
        Bundle bundle = new Bundle();
        bundle.putString("urlImg",urlImg_Slide);
        PhotoFragment photoFragment = new PhotoFragment();
        photoFragment.setArguments(bundle);
        return photoFragment;
    }

    @Override
    public int getItemCount() {
        if(mList != null){
            return mList.size();
        }
        return 0;
    }
}
