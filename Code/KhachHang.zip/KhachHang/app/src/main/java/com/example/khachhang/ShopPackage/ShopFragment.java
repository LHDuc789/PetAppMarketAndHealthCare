package com.example.khachhang.ShopPackage;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.example.khachhang.CartPackage.Cart;
import com.example.khachhang.CartPackage.CartFragment;
import com.example.khachhang.Interface.ClickItemPetBan;
import com.example.khachhang.Main.MainActivity;
import com.example.khachhang.R;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


public class ShopFragment extends Fragment {

    private View mView;
    private RecyclerView rcvPetBan;
    private MainActivity mainActivity;
    ArrayList<PetBan> petbans;
    int lastsize;
    PetBanAdapter petBanAdapter;
    private FrameLayout rootView;
    private ProgressDialog progressDialog;

    public static final String TAG = ShopFragment.class.getName();
    public ShopFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_shop, container, false);
        initUi();
        getPetBanListFromRealtimeDataBase();
        return mView;
    }

    public void initUi(){
        //Khoi tao gamesActivity de su dung.
        mainActivity = (MainActivity) getActivity();
        progressDialog = new ProgressDialog(mainActivity);

//        rootView = mView.findViewById(R.id.apps_root_view);
        rcvPetBan = mView.findViewById(R.id.PetBanList);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mainActivity);
        rcvPetBan.setLayoutManager(linearLayoutManager);

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mainActivity,DividerItemDecoration.VERTICAL);
        rcvPetBan.addItemDecoration(itemDecoration);

        petbans = new ArrayList<>();

        petBanAdapter = new PetBanAdapter(mainActivity, petbans, new ClickItemPetBan() {
            @Override
            public void onClickItemPetBan(PetBan petBan) {
                mainActivity.sendDataToDetailPetBanFragment(petBan);
            }

            @Override
            public void onClickDeleteCart(Cart cart) {
//                deletePetBan(petBan);
            }

            @Override
            public void onClickEditPetBan(PetBan petBan) {
//                mainActivity.sendDataToEditPetBanFragment(petBan);
            }
        });

        rcvPetBan.setAdapter(petBanAdapter);

        //Gan Option Menu len Fragment.
        setHasOptionsMenu(true);

    }

    public void getPetBanListFromRealtimeDataBase() {
        //Goi toi Firebase voi key parent la Games.
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("PetBan");
        DatabaseReference myRef_re = database.getReference("PetBan");

        //Lay ra phan tu cuoi cung
        myRef_re.orderByKey().limitToLast(1).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                PetBan d = snapshot.getValue(PetBan.class);
                if (d != null) {
                    //Chi lay phan so cua IdPet
                    String[] part = d.getIdPet().split("(?<=\\D)(?=\\d)");
                    lastsize = Integer.parseInt(part[1]);
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });

        myRef.addChildEventListener(new ChildEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                PetBan c = snapshot.getValue(PetBan.class);
                if (c != null) {
                    petbans.add(c);
                    petBanAdapter.notifyDataSetChanged();
                }
            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}