package com.example.khachhang.Main;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.khachhang.CarePackage.AddPetNuoiFragment;
import com.example.khachhang.CarePackage.DetailPetNuoiFragment;
import com.example.khachhang.CarePackage.EditPetNuoiFragment;
import com.example.khachhang.CarePackage.PetNuoi;
import com.example.khachhang.CartPackage.Cart;
import com.example.khachhang.CartPackage.CartFragment;
import com.example.khachhang.ChatPackage.Chat;
import com.example.khachhang.ChatPackage.MessageActivity;
import com.example.khachhang.R;
import com.example.khachhang.ShopPackage.DetailPetBanFragment;
import com.example.khachhang.ShopPackage.PetBan;
import com.example.khachhang.UserPackage.ADetailCustomerFragment;
import com.example.khachhang.UserPackage.Customer;
import com.example.khachhang.UserPackage.EditCustomerFragment;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

@SuppressWarnings("deprecation")
public class MainActivity extends AppCompatActivity {
    private TabLayout mTabLayout;
    private ViewPager mViewPager;

    private ProgressDialog progressDialog;

    public static int check = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTabLayout = (TabLayout) findViewById(R.id.tab_layout);
        mViewPager = (ViewPager) findViewById(R.id.view_pager);
        progressDialog = new ProgressDialog(this);
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mViewPager.setAdapter(viewPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        //Truy cap vao User theo Uid
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("PetNuoi");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot1 : snapshot.getChildren()){
                    PetNuoi petNuoi = snapshot1.getValue(PetNuoi.class);
                    if(petNuoi.getIdUser().equals(user.getUid())){
                        mTabLayout.getTabAt(2).view.setEnabled(true);
                        break;
                    }
                    else {
                        mTabLayout.getTabAt(2).view.setEnabled(false);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        DatabaseReference myRef1 = database.getReference("PetNuoi");
        DatabaseReference myRef2 = database.getReference("Like");

        myRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot2 : snapshot.getChildren()){
                    PetNuoi petNuoi1 = snapshot2.getValue(PetNuoi.class);
                    if(petNuoi1!=null){
                        myRef2.child(user.getUid()).child(petNuoi1.getIdPet()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.getValue()==null){
                                    myRef2.child(user.getUid()).child(petNuoi1.getIdPet()).setValue(false);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    public void sendDataToDetailPetBanFragment(PetBan petban) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, DetailPetBanFragment.getInstance(petban));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(DetailPetBanFragment.TAG);
        fragmentTransaction.commit();
    }

    public void sendDataToDetailPetNuoiFragment(PetNuoi petnuoi) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, DetailPetNuoiFragment.getInstance(petnuoi));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(DetailPetNuoiFragment.TAG);
        fragmentTransaction.commit();
    }

    public void sendDataToDetailCartFragment(Customer customer) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, CartFragment.getInstance(customer));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(CartFragment.TAG);
        fragmentTransaction.commit();
    }


    public void sendDataToDetailACustomerFragment(Customer customer) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, ADetailCustomerFragment.getInstance(customer));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(ADetailCustomerFragment.TAG);
        fragmentTransaction.commit();
    }

    public void sendDataToEditCustomerFragment(Customer customer) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, EditCustomerFragment.getInstance(customer));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void sendDataToAddPetNuoiFragment(int lastsize) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, AddPetNuoiFragment.getInstance(lastsize));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void sendDataToEditPetNuoiFragment(PetNuoi petNuoi) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
        fragmentTransaction.replace(R.id.root_view, EditPetNuoiFragment.getInstance(petNuoi));
        //Back lai content_frame ma van luu trang thai truoc.
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.detailAccount:
                //Lay ra doi tuong user dang login hien tai.
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if(user == null){
                    return false;
                }
                //Lay Uid cua user hien tai.
                String Uid = user.getUid();
                //Truy cap vao User theo Uid
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("User");
                myRef.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        String UserId = snapshot.getKey();
                        assert UserId != null;
                        if(UserId.equals(Uid)){
                            Customer c = snapshot.getValue(Customer.class);
                            if (c != null) {
                                //Dua cac thong tin cua User sang fragment ADetailCustomer
                                Customer detailcustomer = new Customer(c.getIdUser(),c.getName(),c.getEmail(),c.getAddress(),c.getPhone(),c.getUrlImageIcon(),c.getCreateDate(),c.getStatus());
                                sendDataToDetailACustomerFragment(detailcustomer);
                            }
                        }
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                return true;

            case R.id.detailCart:
                //Lay ra doi tuong user dang login hien tai.
                FirebaseUser user_re = FirebaseAuth.getInstance().getCurrentUser();
                if(user_re == null){
                    return false;
                }
                //Lay Uid cua user hien tai.
                String Uid_re = user_re.getUid();
                //Truy cap vao User theo Uid
                FirebaseDatabase database_re = FirebaseDatabase.getInstance();
                DatabaseReference myRef_re = database_re.getReference("User");
                myRef_re.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        String UserId = snapshot.getKey();
                        assert UserId != null;
                        if(UserId.equals(Uid_re)){
                            Customer c = snapshot.getValue(Customer.class);
                            if (c != null) {
                                //Dua cac thong tin cua User sang fragment ADetailCustomer
                                Customer detailcustomer = new Customer(c.getIdUser(),c.getName(),c.getEmail(),c.getAddress(),c.getPhone(),c.getUrlImageIcon(),c.getCreateDate(),c.getStatus());
                                sendDataToDetailCartFragment(detailcustomer);
                            }
                        }
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                return true;
            case R.id.logoutAccount:

                new AlertDialog.Builder(this)
                        .setTitle(getString(R.string.app_name))
                        .setMessage("Quá Trình Này Sẽ Khiến Bạn Đăng Xuất Khỏi Tài Khoản Hiện Tại.")
                        .setPositiveButton("Đồng Ý", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                progressDialog.setMessage("Đang Đăng Xuất Tài Khoản Hiện Tại.");
                                progressDialog.show();
                                Status("offline");
                                Handler handler = new Handler();
                                handler.postDelayed(() -> {
                                    progressDialog.dismiss();
//                        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
//                        //Thay the content_frame thanh DetailFragment chua cac thuoc tinh lay duoc tu Object Games.
//                        fragmentTransaction.replace(R.id.root_view, new PetFragment());
//                        //Back lai content_frame ma van luu trang thai truoc.
//                        fragmentTransaction.addToBackStack(null);
//                        fragmentTransaction.commit();
                                    Toast.makeText(MainActivity.this,"Đăng Xuất Tài Khoản Thành Công.",Toast.LENGTH_LONG).show();
                                    FirebaseAuth.getInstance().signOut();
                                    Intent intent = new Intent(MainActivity.this, SignInActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                },1000);
                            }
                        })
                        .setNegativeButton("Không Đồng Ý", null)
                        .show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void Status(String status){
        FirebaseUser user_status = FirebaseAuth.getInstance().getCurrentUser();
        if(user_status!=null){
            DatabaseReference database = FirebaseDatabase.getInstance().getReference("User").child(user_status.getUid());

            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("status", status);

            database.updateChildren(hashMap);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Status("online");
    }

//    @Override
//    protected void onPause() {
//        super.onPause();
//        Status("online");
//    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Status("offline");
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(check == 0){
            Status("offline");
        }
        else{
            Status("online");
        }
    }
}